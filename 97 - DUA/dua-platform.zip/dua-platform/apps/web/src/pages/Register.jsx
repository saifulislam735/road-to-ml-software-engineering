import { Link, useNavigate } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import toast from 'react-hot-toast';
import Input from '../components/ui/Input';
import Button from '../components/ui/Button';
import { useRegister } from '../hooks/useAuth';
import { apiError } from '../utils/helpers';

const schema = z.object({
  username: z
    .string()
    .min(3, 'At least 3 characters')
    .max(30, 'Max 30 characters')
    .regex(/^[a-zA-Z0-9_]+$/, 'Only letters, numbers and underscores'),
  email: z.string().email('Enter a valid email'),
  password: z.string().min(8, 'At least 8 characters'),
});

export default function Register() {
  const navigate = useNavigate();
  const registerMutation = useRegister();
  const { register, handleSubmit, formState: { errors } } = useForm({ resolver: zodResolver(schema) });

  const onSubmit = (data) => {
    registerMutation.mutate(data, {
      onSuccess: () => navigate('/inbox'),
      onError: (err) => toast.error(apiError(err, 'Registration failed')),
    });
  };

  return (
    <div className="min-h-screen flex items-center justify-center px-4 bg-gray-50">
      <div className="w-full max-w-sm bg-white rounded-xl shadow-sm border border-gray-100 p-6">
        <Link to="/" className="block text-center text-3xl mb-2">🤲</Link>
        <h1 className="text-xl font-semibold text-center text-gray-900">Create your profile</h1>
        <p className="text-sm text-gray-500 text-center mb-6">Get your shareable dua link</p>
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
          <Input label="Username" placeholder="yourname" error={errors.username?.message} {...register('username')} />
          <Input label="Email" type="email" placeholder="you@example.com" error={errors.email?.message} {...register('email')} />
          <Input label="Password" type="password" placeholder="At least 8 characters" error={errors.password?.message} {...register('password')} />
          <Button type="submit" isLoading={registerMutation.isPending} className="w-full">Get started</Button>
        </form>
        <p className="text-sm text-gray-500 text-center mt-4">
          Already have an account?{' '}
          <Link to="/login" className="text-brand-600 font-medium hover:underline">Log in</Link>
        </p>
      </div>
    </div>
  );
}
