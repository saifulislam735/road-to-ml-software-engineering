import { jest } from '@jest/globals';

process.env.DATABASE_URL = 'postgresql://test';
process.env.JWT_SECRET = 'test-secret';

jest.unstable_mockModule('../src/repositories/dua.repo.js', () => ({
  duaRepo: {
    create: jest.fn(),
    findById: jest.fn(),
    findInbox: jest.fn(),
    countInbox: jest.fn(),
    markRead: jest.fn(),
    delete: jest.fn(),
    createReport: jest.fn(),
  },
}));

jest.unstable_mockModule('../src/repositories/user.repo.js', () => ({
  userRepo: {
    findByEmail: jest.fn(),
    findByUsername: jest.fn(),
    findById: jest.fn(),
    create: jest.fn(),
    update: jest.fn(),
  },
}));

const { duaRepo } = await import('../src/repositories/dua.repo.js');
const { userRepo } = await import('../src/repositories/user.repo.js');
const { duaService } = await import('../src/services/dua.service.js');

describe('duaService.send', () => {
  beforeEach(() => jest.clearAllMocks());

  it('creates a dua for an active user', async () => {
    userRepo.findByUsername.mockResolvedValue({ id: 'owner1', isPaused: false, isBanned: false });
    duaRepo.create.mockResolvedValue({ id: 'd1', createdAt: new Date() });
    const result = await duaService.send('rafi', 'May Allah grant you success.');
    expect(result.id).toBe('d1');
    expect(duaRepo.create).toHaveBeenCalledWith({ message: 'May Allah grant you success.', ownerId: 'owner1' });
  });

  it('throws 404 for unknown user', async () => {
    userRepo.findByUsername.mockResolvedValue(null);
    await expect(duaService.send('ghost', 'hello there friend')).rejects.toMatchObject({ statusCode: 404 });
  });

  it('throws 403 when owner is paused', async () => {
    userRepo.findByUsername.mockResolvedValue({ id: 'owner1', isPaused: true, isBanned: false });
    await expect(duaService.send('rafi', 'hello there friend')).rejects.toMatchObject({
      statusCode: 403,
      message: 'This user is not accepting duas right now.',
    });
  });
});

describe('duaService inbox + ownership', () => {
  beforeEach(() => jest.clearAllMocks());

  it('returns paginated inbox', async () => {
    duaRepo.findInbox.mockResolvedValue([{ id: 'd1' }]);
    duaRepo.countInbox.mockResolvedValue(45);
    const result = await duaService.getInbox('u1', { page: 1, limit: 20 });
    expect(result.pagination).toEqual({ page: 1, limit: 20, total: 45, totalPages: 3 });
  });

  it('blocks deleting someone else\'s dua with 403', async () => {
    duaRepo.findById.mockResolvedValue({ id: 'd1', ownerId: 'someone-else' });
    await expect(duaService.delete('u1', 'd1')).rejects.toMatchObject({ statusCode: 403 });
    expect(duaRepo.delete).not.toHaveBeenCalled();
  });

  it('marks own dua as read', async () => {
    duaRepo.findById.mockResolvedValue({ id: 'd1', ownerId: 'u1' });
    duaRepo.markRead.mockResolvedValue({});
    const result = await duaService.markRead('u1', 'd1');
    expect(result.success).toBe(true);
  });
});
