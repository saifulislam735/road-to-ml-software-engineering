import { formatDistanceToNow, format } from 'date-fns';

export function relativeTime(date) {
  try {
    return formatDistanceToNow(new Date(date), { addSuffix: true });
  } catch {
    return '';
  }
}

export function formatDate(date) {
  try {
    return format(new Date(date), 'MMM d, yyyy');
  } catch {
    return '';
  }
}

export function truncate(str, n = 60) {
  if (!str) return '';
  return str.length > n ? str.slice(0, n) + '…' : str;
}

export async function copyToClipboard(text) {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch {
    const el = document.createElement('textarea');
    el.value = text;
    document.body.appendChild(el);
    el.select();
    document.execCommand('copy');
    document.body.removeChild(el);
    return true;
  }
}

export function initials(nameOrUsername = '') {
  return nameOrUsername
    .split(' ')
    .map((s) => s[0])
    .filter(Boolean)
    .slice(0, 2)
    .join('')
    .toUpperCase();
}

export function apiError(err, fallback = 'Something went wrong') {
  return err?.response?.data?.message || fallback;
}
