import { Router } from 'express';
import { z } from 'zod';
import { adminController } from '../controllers/admin.controller.js';
import { adminAuthMiddleware } from '../middleware/adminAuth.middleware.js';
import { validate } from '../middleware/validate.middleware.js';

const banSchema = z.object({
  reason: z.string().min(10, 'Reason must be at least 10 characters').max(300),
});

const resolveSchema = z.object({
  hideDua: z.boolean().optional(),
});

const router = Router();

router.use(adminAuthMiddleware);

router.get('/stats', adminController.stats);

router.get('/users', adminController.users);
router.get('/users/:id', adminController.user);
router.patch('/users/:id/ban', validate(banSchema), adminController.banUser);
router.patch('/users/:id/unban', adminController.unbanUser);
router.delete('/users/:id', adminController.deleteUser);

router.get('/duas', adminController.duas);
router.patch('/duas/:id/hide', adminController.hideDua);
router.patch('/duas/:id/unhide', adminController.unhideDua);
router.delete('/duas/:id', adminController.deleteDua);

router.get('/reports', adminController.reports);
router.patch('/reports/:id/resolve', validate(resolveSchema), adminController.resolveReport);
router.patch('/reports/:id/dismiss', adminController.dismissReport);

export default router;
