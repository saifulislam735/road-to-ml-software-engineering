#!/bin/bash

# Daily PostgreSQL backup with 7-day retention.
# Run on the VPS via cron: 0 2 * * * /home/deploy/dua-platform/scripts/backup-db.sh >> /home/deploy/logs/backup.log 2>&1

# Config
DB_CONTAINER="dua_postgres_prod"
DB_USER="dua_user"
DB_NAME="dua_db"
BACKUP_DIR="/home/deploy/backups/db"
RETENTION_DAYS=7

# Create backup dir if missing
mkdir -p "$BACKUP_DIR"

# Filename with timestamp
FILENAME="$BACKUP_DIR/dua_db_$(date +%Y-%m-%d_%H-%M).sql.gz"

# Dump and compress
docker exec "$DB_CONTAINER" pg_dump -U "$DB_USER" "$DB_NAME" | gzip > "$FILENAME"

# Check if dump succeeded
if [ $? -eq 0 ]; then
  echo "$(date): Backup successful: $FILENAME"
else
  echo "$(date): Backup FAILED" >&2
  exit 1
fi

# Delete backups older than RETENTION_DAYS
find "$BACKUP_DIR" -name "*.sql.gz" -mtime +$RETENTION_DAYS -delete

echo "$(date): Old backups cleaned. Current backups:"
ls -lh "$BACKUP_DIR"
