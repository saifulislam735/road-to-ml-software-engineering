import { AppError } from '../utils/AppError.js';
import { adminRepo } from '../repositories/admin.repo.js';

export const adminService = {
  async getStats(chart) {
    if (chart === 'duas_daily') return { chart: await adminRepo.dailyCounts('dua') };
    if (chart === 'users_daily') return { chart: await adminRepo.dailyCounts('user') };

    const [
      totalUsers, usersToday, banned,
      totalDuas, duasToday, hidden,
      pending, resolved, dismissed,
      recentReports, recentUsers,
    ] = await Promise.all([
      adminRepo.countUsers(),
      adminRepo.countUsersToday(),
      adminRepo.countBannedUsers(),
      adminRepo.countDuas(),
      adminRepo.countDuasToday(),
      adminRepo.countHiddenDuas(),
      adminRepo.countReportsByStatus('pending'),
      adminRepo.countReportsByStatus('resolved'),
      adminRepo.countReportsByStatus('dismissed'),
      adminRepo.recentPendingReports(5),
      adminRepo.recentUsers(5),
    ]);

    return {
      users: { total: totalUsers, today: usersToday, banned },
      duas: { total: totalDuas, today: duasToday, hidden },
      reports: { pending, resolved, dismissed },
      recent: { reports: recentReports, users: recentUsers },
    };
  },

  async getUsers({ page = 1, limit = 20, search, banned }) {
    const take = Math.min(Math.max(limit, 1), 50);
    const skip = (Math.max(page, 1) - 1) * take;
    const bannedFilter = banned === 'true' ? true : banned === 'false' ? false : undefined;
    const [users, total] = await adminRepo.findUsers({ skip, take, search, banned: bannedFilter });
    return {
      users: users.map((u) => ({ ...u, duasReceived: u._count.duas, _count: undefined })),
      pagination: { page, limit: take, total, totalPages: Math.ceil(total / take) || 1 },
    };
  },

  async getUser(id) {
    const user = await adminRepo.findUserDetail(id);
    if (!user) throw new AppError('User not found', 404, 'NOT_FOUND');
    const reportCount = await adminRepo.countReportsAgainstUser(id);
    return { ...user, duasReceived: user._count.duas, reportCount, _count: undefined };
  },

  async banUser(id, reason) {
    const user = await adminRepo.findUserDetail(id);
    if (!user) throw new AppError('User not found', 404, 'NOT_FOUND');
    if (user.role === 'ADMIN') throw new AppError('Cannot ban an admin', 403, 'FORBIDDEN');
    await adminRepo.setBan(id, true, reason);
    await adminRepo.hideAllDuasOfUser(id);
    return { success: true };
  },

  async unbanUser(id) {
    const user = await adminRepo.findUserDetail(id);
    if (!user) throw new AppError('User not found', 404, 'NOT_FOUND');
    await adminRepo.setBan(id, false, null);
    return { success: true };
  },

  async deleteUser(id) {
    const user = await adminRepo.findUserDetail(id);
    if (!user) throw new AppError('User not found', 404, 'NOT_FOUND');
    if (user.role === 'ADMIN') throw new AppError('Cannot delete an admin', 403, 'FORBIDDEN');
    await adminRepo.deleteUser(id);
    return { success: true };
  },

  async getDuas({ page = 1, limit = 20, hidden, reported }) {
    const take = Math.min(Math.max(limit, 1), 50);
    const skip = (Math.max(page, 1) - 1) * take;
    const hiddenFilter = hidden === 'true' ? true : hidden === 'false' ? false : undefined;
    const [duas, total] = await adminRepo.findDuas({
      skip, take,
      hidden: hiddenFilter,
      reported: reported === 'true',
    });
    return {
      duas: duas.map((d) => ({ ...d, reportCount: d._count.reports, _count: undefined })),
      pagination: { page, limit: take, total, totalPages: Math.ceil(total / take) || 1 },
    };
  },

  async setDuaHidden(id, isHidden) {
    await adminRepo.setDuaHidden(id, isHidden).catch(() => {
      throw new AppError('Dua not found', 404, 'NOT_FOUND');
    });
    return { success: true };
  },

  async deleteDua(id) {
    await adminRepo.deleteDua(id).catch(() => {
      throw new AppError('Dua not found', 404, 'NOT_FOUND');
    });
    return { success: true };
  },

  async getReports({ page = 1, limit = 20, status }) {
    const take = Math.min(Math.max(limit, 1), 50);
    const skip = (Math.max(page, 1) - 1) * take;
    const [reports, total] = await adminRepo.findReports({ skip, take, status });
    return {
      reports,
      pagination: { page, limit: take, total, totalPages: Math.ceil(total / take) || 1 },
    };
  },

  async resolveReport(id, hideDua = false) {
    const report = await adminRepo.findReportById(id);
    if (!report) throw new AppError('Report not found', 404, 'NOT_FOUND');
    await adminRepo.setReportStatus(id, 'resolved');
    if (hideDua) await adminRepo.setDuaHidden(report.duaId, true);
    return { success: true };
  },

  async dismissReport(id) {
    const report = await adminRepo.findReportById(id);
    if (!report) throw new AppError('Report not found', 404, 'NOT_FOUND');
    await adminRepo.setReportStatus(id, 'dismissed');
    return { success: true };
  },
};
