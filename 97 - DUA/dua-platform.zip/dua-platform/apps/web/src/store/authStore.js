import { create } from 'zustand';

const STORAGE_KEY = 'dua_auth';

export const useAuthStore = create((set) => ({
  user: null,
  token: null,
  isAuthenticated: false,
  hydrated: false,

  login: (token, user) => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify({ token, user }));
    set({ token, user, isAuthenticated: true });
  },

  logout: () => {
    localStorage.removeItem(STORAGE_KEY);
    set({ token: null, user: null, isAuthenticated: false });
    if (window.location.pathname !== '/login') {
      window.location.href = '/login';
    }
  },

  setUser: (user) => {
    set((state) => {
      localStorage.setItem(STORAGE_KEY, JSON.stringify({ token: state.token, user }));
      return { user };
    });
  },

  hydrate: () => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) {
        const { token, user } = JSON.parse(raw);
        if (token && user) {
          set({ token, user, isAuthenticated: true, hydrated: true });
          return;
        }
      }
    } catch {
      localStorage.removeItem(STORAGE_KEY);
    }
    set({ hydrated: true });
  },
}));
