import { prisma } from '../config/db.js';

function startOfToday() {
  const d = new Date();
  d.setHours(0, 0, 0, 0);
  return d;
}

function daysAgo(n) {
  const d = startOfToday();
  d.setDate(d.getDate() - n);
  return d;
}

export const adminRepo = {
  // ---- Stats ----
  countUsers: () => prisma.user.count(),
  countUsersToday: () => prisma.user.count({ where: { createdAt: { gte: startOfToday() } } }),
  countBannedUsers: () => prisma.user.count({ where: { isBanned: true } }),
  countDuas: () => prisma.dua.count(),
  countDuasToday: () => prisma.dua.count({ where: { createdAt: { gte: startOfToday() } } }),
  countHiddenDuas: () => prisma.dua.count({ where: { isHidden: true } }),
  countReportsByStatus: (status) => prisma.report.count({ where: { status } }),

  async dailyCounts(model, days = 7) {
    const since = daysAgo(days - 1);
    const rows = await prisma[model].findMany({
      where: { createdAt: { gte: since } },
      select: { createdAt: true },
    });
    const buckets = {};
    for (let i = 0; i < days; i++) {
      const d = daysAgo(days - 1 - i);
      buckets[d.toISOString().slice(0, 10)] = 0;
    }
    for (const row of rows) {
      const key = row.createdAt.toISOString().slice(0, 10);
      if (key in buckets) buckets[key] += 1;
    }
    return Object.entries(buckets).map(([date, count]) => ({ date, count }));
  },

  recentPendingReports: (take = 5) =>
    prisma.report.findMany({
      where: { status: 'pending' },
      orderBy: { createdAt: 'desc' },
      take,
      include: { dua: { select: { id: true, message: true, owner: { select: { id: true, username: true } } } } },
    }),

  recentUsers: (take = 5) =>
    prisma.user.findMany({
      orderBy: { createdAt: 'desc' },
      take,
      select: { id: true, username: true, name: true, avatarUrl: true, createdAt: true },
    }),

  // ---- Users ----
  findUsers: ({ skip, take, search, banned }) => {
    const where = {
      ...(search
        ? {
            OR: [
              { username: { contains: search, mode: 'insensitive' } },
              { email: { contains: search, mode: 'insensitive' } },
            ],
          }
        : {}),
      ...(banned === true ? { isBanned: true } : banned === false ? { isBanned: false } : {}),
    };
    return Promise.all([
      prisma.user.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        skip,
        take,
        select: {
          id: true, username: true, email: true, name: true, avatarUrl: true,
          isBanned: true, role: true, createdAt: true,
          _count: { select: { duas: true } },
        },
      }),
      prisma.user.count({ where }),
    ]);
  },

  findUserDetail: (id) =>
    prisma.user.findUnique({
      where: { id },
      select: {
        id: true, username: true, email: true, name: true, bio: true, avatarUrl: true,
        isPaused: true, isBanned: true, banReason: true, role: true, createdAt: true,
        duas: {
          orderBy: { createdAt: 'desc' },
          take: 20,
          select: { id: true, message: true, isHidden: true, isRead: true, createdAt: true, _count: { select: { reports: true } } },
        },
        _count: { select: { duas: true } },
      },
    }),

  countReportsAgainstUser: (userId) => prisma.report.count({ where: { dua: { ownerId: userId } } }),

  setBan: (id, isBanned, banReason = null) =>
    prisma.user.update({ where: { id }, data: { isBanned, banReason } }),

  deleteUser: (id) => prisma.user.delete({ where: { id } }),

  // ---- Duas ----
  findDuas: ({ skip, take, hidden, reported }) => {
    const where = {
      ...(hidden === true ? { isHidden: true } : hidden === false ? { isHidden: false } : {}),
      ...(reported ? { reports: { some: {} } } : {}),
    };
    return Promise.all([
      prisma.dua.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        skip,
        take,
        include: {
          owner: { select: { id: true, username: true } },
          _count: { select: { reports: true } },
        },
      }),
      prisma.dua.count({ where }),
    ]);
  },

  setDuaHidden: (id, isHidden) => prisma.dua.update({ where: { id }, data: { isHidden } }),

  deleteDua: (id) => prisma.dua.delete({ where: { id } }),

  hideAllDuasOfUser: (ownerId) => prisma.dua.updateMany({ where: { ownerId }, data: { isHidden: true } }),

  // ---- Reports ----
  findReports: ({ skip, take, status }) => {
    const where = status ? { status } : {};
    return Promise.all([
      prisma.report.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        skip,
        take,
        include: {
          dua: { select: { id: true, message: true, isHidden: true, owner: { select: { id: true, username: true } } } },
        },
      }),
      prisma.report.count({ where }),
    ]);
  },

  findReportById: (id) => prisma.report.findUnique({ where: { id }, include: { dua: true } }),

  setReportStatus: (id, status) => prisma.report.update({ where: { id }, data: { status } }),
};
