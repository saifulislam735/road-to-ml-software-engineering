import { prisma } from '../config/db.js';

export const duaRepo = {
  create: (data) => prisma.dua.create({ data }),

  findById: (id) => prisma.dua.findUnique({ where: { id } }),

  findInbox: ({ ownerId, skip, take, unreadOnly }) =>
    prisma.dua.findMany({
      where: { ownerId, isHidden: false, ...(unreadOnly ? { isRead: false } : {}) },
      orderBy: { createdAt: 'desc' },
      skip,
      take,
      select: { id: true, message: true, isRead: true, createdAt: true },
    }),

  countInbox: ({ ownerId, unreadOnly }) =>
    prisma.dua.count({
      where: { ownerId, isHidden: false, ...(unreadOnly ? { isRead: false } : {}) },
    }),

  markRead: (id) => prisma.dua.update({ where: { id }, data: { isRead: true } }),

  delete: (id) => prisma.dua.delete({ where: { id } }),

  createReport: (data) => prisma.report.create({ data }),
};
