import { useState } from 'react';
import { NavLink, Outlet, Link } from 'react-router-dom';
import { LayoutDashboard, Users, MessageSquare, Flag, ArrowLeft, Menu, X } from 'lucide-react';
import { useAuthStore } from '../../store/authStore';
import { useAdminStats } from '../../hooks/useAdmin';

const navItems = [
  { to: '/admin', label: 'Dashboard', icon: LayoutDashboard, end: true },
  { to: '/admin/users', label: 'Users', icon: Users },
  { to: '/admin/duas', label: 'Duas', icon: MessageSquare },
  { to: '/admin/reports', label: 'Reports', icon: Flag },
];

export default function AdminLayout() {
  const user = useAuthStore((s) => s.user);
  const { data: stats } = useAdminStats();
  const pending = stats?.reports?.pending || 0;
  const [open, setOpen] = useState(false);

  const linkClass = ({ isActive }) =>
    `flex items-center gap-3 px-4 py-2.5 text-sm rounded-lg transition-colors ${
      isActive
        ? 'bg-slate-800 text-white border-l-2 border-brand-400'
        : 'text-slate-300 hover:bg-slate-800/60 hover:text-white'
    }`;

  const sidebar = (
    <div className="flex flex-col h-full">
      <div className="px-4 py-5 text-white font-semibold text-lg">🤲 Admin</div>
      <nav className="flex-1 px-2 space-y-1">
        {navItems.map(({ to, label, icon: Icon, end }) => (
          <NavLink key={to} to={to} end={end} className={linkClass} onClick={() => setOpen(false)}>
            <Icon size={18} />
            <span>{label}</span>
            {label === 'Reports' && pending > 0 && (
              <span className="ml-auto bg-red-500 text-white text-xs rounded-full px-2 py-0.5">{pending}</span>
            )}
          </NavLink>
        ))}
      </nav>
      <div className="px-2 pb-4 border-t border-slate-800 pt-3">
        <Link to="/inbox" className="flex items-center gap-3 px-4 py-2.5 text-sm text-slate-400 hover:text-white rounded-lg hover:bg-slate-800/60">
          <ArrowLeft size={18} /> Back to app
        </Link>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-100 flex">
      {/* Desktop sidebar */}
      <aside className="hidden md:block w-56 bg-slate-900 shrink-0">{sidebar}</aside>

      {/* Mobile sidebar */}
      {open && (
        <div className="fixed inset-0 z-40 md:hidden">
          <div className="absolute inset-0 bg-black/50" onClick={() => setOpen(false)} />
          <aside className="absolute left-0 top-0 bottom-0 w-56 bg-slate-900">{sidebar}</aside>
        </div>
      )}

      <div className="flex-1 min-w-0">
        <header className="bg-white border-b border-gray-200 h-14 flex items-center justify-between px-4 sticky top-0 z-10">
          <div className="flex items-center gap-3">
            <button className="md:hidden text-gray-600" onClick={() => setOpen((o) => !o)} aria-label="Menu">
              {open ? <X size={20} /> : <Menu size={20} />}
            </button>
            <h1 className="font-semibold text-gray-900">Admin Panel</h1>
          </div>
          <span className="text-sm text-gray-500">{user?.name || user?.username}</span>
        </header>
        <main className="p-4 md:p-6 max-w-6xl">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
