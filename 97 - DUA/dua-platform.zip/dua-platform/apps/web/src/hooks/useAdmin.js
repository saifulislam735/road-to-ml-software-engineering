import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { adminApi } from '../services/api';

export function useAdminStats() {
  return useQuery({
    queryKey: ['admin', 'stats'],
    queryFn: () => adminApi.getStats().then((r) => r.data),
    refetchInterval: 60_000,
  });
}

export function useAdminChart(chart) {
  return useQuery({
    queryKey: ['admin', 'stats', chart],
    queryFn: () => adminApi.getStats({ chart }).then((r) => r.data.chart),
  });
}

export function useAdminUsers(params) {
  return useQuery({
    queryKey: ['admin', 'users', params],
    queryFn: () => adminApi.getUsers(params).then((r) => r.data),
    placeholderData: (prev) => prev,
  });
}

export function useAdminUser(id) {
  return useQuery({
    queryKey: ['admin', 'users', id],
    queryFn: () => adminApi.getUser(id).then((r) => r.data),
    enabled: !!id,
  });
}

export function useBanUser() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ id, reason }) => adminApi.banUser(id, { reason }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['admin'] }),
  });
}

export function useUnbanUser() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (id) => adminApi.unbanUser(id),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['admin'] }),
  });
}

export function useDeleteUser() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (id) => adminApi.deleteUser(id),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['admin'] }),
  });
}

export function useAdminDuas(params) {
  return useQuery({
    queryKey: ['admin', 'duas', params],
    queryFn: () => adminApi.getDuas(params).then((r) => r.data),
    placeholderData: (prev) => prev,
  });
}

export function useHideDua() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ id, hidden }) => (hidden ? adminApi.hideDua(id) : adminApi.unhideDua(id)),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['admin'] }),
  });
}

export function useAdminDeleteDua() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (id) => adminApi.deleteDua(id),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['admin'] }),
  });
}

export function useAdminReports(params) {
  return useQuery({
    queryKey: ['admin', 'reports', params],
    queryFn: () => adminApi.getReports(params).then((r) => r.data),
    placeholderData: (prev) => prev,
  });
}

export function useResolveReport() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ id, hideDua }) => adminApi.resolveReport(id, { hideDua }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['admin'] }),
  });
}

export function useDismissReport() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (id) => adminApi.dismissReport(id),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['admin'] }),
  });
}
