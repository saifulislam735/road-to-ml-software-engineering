import toast from 'react-hot-toast';
import { Copy, Instagram, MessageCircle } from 'lucide-react';
import Navbar from '../components/Navbar';
import Button from '../components/ui/Button';
import { useAuthStore } from '../store/authStore';
import { copyToClipboard } from '../utils/helpers';

export default function Share() {
  const user = useAuthStore((s) => s.user);
  const appUrl = import.meta.env.VITE_APP_URL || window.location.origin;
  const profileUrl = `${appUrl}/u/${user?.username}`;

  const handleCopy = async () => {
    await copyToClipboard(profileUrl);
    toast.success('Link copied!');
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      <main className="max-w-lg mx-auto px-4 py-6 space-y-6">
        <h1 className="text-xl font-semibold text-gray-900">Share your link</h1>

        <div className="bg-gradient-to-br from-brand-500 to-brand-700 rounded-xl p-6 text-center text-white shadow-sm">
          <div className="text-4xl mb-2">🤲</div>
          <p className="font-semibold text-lg">Send me a dua</p>
          <p className="mt-3 bg-white/20 rounded-lg px-3 py-2 text-sm break-all font-mono">{profileUrl}</p>
          <Button onClick={handleCopy} variant="secondary" className="mt-4 w-full">
            <Copy size={16} /> Copy link
          </Button>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 space-y-4">
          <h2 className="font-semibold text-gray-900">How to share</h2>
          <div className="flex gap-3">
            <div className="w-10 h-10 rounded-lg bg-pink-100 text-pink-600 flex items-center justify-center shrink-0">
              <Instagram size={20} />
            </div>
            <div>
              <p className="text-sm font-medium text-gray-800">Instagram Stories</p>
              <p className="text-sm text-gray-500">
                Copy your link, add a Story, and use the "Link" sticker to paste it. Add text like
                "Send me a dua 🤲".
              </p>
            </div>
          </div>
          <div className="flex gap-3">
            <div className="w-10 h-10 rounded-lg bg-blue-100 text-blue-600 flex items-center justify-center shrink-0">
              <MessageCircle size={20} />
            </div>
            <div>
              <p className="text-sm font-medium text-gray-800">Messenger Day / WhatsApp Status</p>
              <p className="text-sm text-gray-500">
                Paste your link in your status with a short message inviting friends to send a dua.
              </p>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
