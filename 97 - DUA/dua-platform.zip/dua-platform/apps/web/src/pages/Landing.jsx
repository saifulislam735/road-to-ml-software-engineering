import { Link } from 'react-router-dom';
import { UserPlus, Link2, Inbox } from 'lucide-react';
import Button from '../components/ui/Button';

const steps = [
  { icon: UserPlus, title: 'Register', desc: 'Create your free profile in seconds.' },
  { icon: Link2, title: 'Share your link', desc: 'Post it on Instagram Stories or Messenger Day.' },
  { icon: Inbox, title: 'Receive duas', desc: 'Read heartfelt anonymous duas in your inbox.' },
];

export default function Landing() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-brand-50 to-white flex flex-col">
      <main className="flex-1 flex flex-col items-center justify-center px-4 py-16 text-center">
        <div className="text-6xl mb-4">🤲</div>
        <h1 className="text-4xl font-semibold text-gray-900 max-w-md">
          Dua
        </h1>
        <p className="mt-3 text-lg text-gray-600 max-w-sm">
          Receive duas from your loved ones, anonymously.
        </p>
        <div className="mt-8 flex flex-col sm:flex-row gap-3 w-full max-w-xs">
          <Link to="/register" className="flex-1">
            <Button className="w-full">Get started</Button>
          </Link>
          <Link to="/login" className="flex-1">
            <Button variant="secondary" className="w-full">Log in</Button>
          </Link>
        </div>

        <div className="mt-16 grid gap-6 sm:grid-cols-3 max-w-2xl w-full">
          {steps.map(({ icon: Icon, title, desc }, i) => (
            <div key={title} className="bg-white rounded-xl shadow-sm border border-gray-100 p-5 text-left">
              <div className="w-10 h-10 rounded-lg bg-brand-100 text-brand-700 flex items-center justify-center mb-3">
                <Icon size={20} />
              </div>
              <p className="text-xs text-brand-600 font-medium">Step {i + 1}</p>
              <h3 className="font-semibold text-gray-900">{title}</h3>
              <p className="text-sm text-gray-500 mt-1">{desc}</p>
            </div>
          ))}
        </div>
      </main>
      <footer className="text-center text-xs text-gray-400 pb-6">
        Made with sincerity 🤲
      </footer>
    </div>
  );
}
