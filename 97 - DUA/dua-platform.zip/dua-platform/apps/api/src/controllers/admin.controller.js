import { catchAsync } from '../utils/catchAsync.js';
import { adminService } from '../services/admin.service.js';

export const adminController = {
  stats: catchAsync(async (req, res) => {
    res.json(await adminService.getStats(req.query.chart));
  }),

  users: catchAsync(async (req, res) => {
    const { page = '1', limit = '20', search, banned } = req.query;
    res.json(await adminService.getUsers({ page: +page, limit: +limit, search, banned }));
  }),

  user: catchAsync(async (req, res) => {
    res.json(await adminService.getUser(req.params.id));
  }),

  banUser: catchAsync(async (req, res) => {
    res.json(await adminService.banUser(req.params.id, req.body.reason));
  }),

  unbanUser: catchAsync(async (req, res) => {
    res.json(await adminService.unbanUser(req.params.id));
  }),

  deleteUser: catchAsync(async (req, res) => {
    res.json(await adminService.deleteUser(req.params.id));
  }),

  duas: catchAsync(async (req, res) => {
    const { page = '1', limit = '20', hidden, reported } = req.query;
    res.json(await adminService.getDuas({ page: +page, limit: +limit, hidden, reported }));
  }),

  hideDua: catchAsync(async (req, res) => {
    res.json(await adminService.setDuaHidden(req.params.id, true));
  }),

  unhideDua: catchAsync(async (req, res) => {
    res.json(await adminService.setDuaHidden(req.params.id, false));
  }),

  deleteDua: catchAsync(async (req, res) => {
    res.json(await adminService.deleteDua(req.params.id));
  }),

  reports: catchAsync(async (req, res) => {
    const { page = '1', limit = '20', status } = req.query;
    res.json(await adminService.getReports({ page: +page, limit: +limit, status }));
  }),

  resolveReport: catchAsync(async (req, res) => {
    res.json(await adminService.resolveReport(req.params.id, req.body?.hideDua === true));
  }),

  dismissReport: catchAsync(async (req, res) => {
    res.json(await adminService.dismissReport(req.params.id));
  }),
};
