import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { env } from '../config/env.js';
import { AppError } from '../utils/AppError.js';
import { userRepo } from '../repositories/user.repo.js';

const SALT_ROUNDS = 12;

export function toPublicUser(user) {
  return {
    id: user.id,
    username: user.username,
    email: user.email,
    name: user.name,
    bio: user.bio,
    avatarUrl: user.avatarUrl,
    isPaused: user.isPaused,
    role: user.role,
  };
}

export function signToken(user) {
  return jwt.sign(
    { id: user.id, username: user.username, email: user.email, role: user.role },
    env.jwtSecret,
    { expiresIn: env.jwtExpiresIn }
  );
}

export const authService = {
  async register({ username, email, password }) {
    const [byEmail, byUsername] = await Promise.all([
      userRepo.findByEmail(email),
      userRepo.findByUsername(username),
    ]);
    if (byEmail) throw new AppError('Email already in use', 409, 'EMAIL_TAKEN');
    if (byUsername) throw new AppError('Username already taken', 409, 'USERNAME_TAKEN');

    const hashed = await bcrypt.hash(password, SALT_ROUNDS);
    const user = await userRepo.create({ username, email, password: hashed });

    return { token: signToken(user), user: toPublicUser(user) };
  },

  async login({ email, password }) {
    const user = await userRepo.findByEmail(email);
    if (!user) throw new AppError('Invalid email or password', 401, 'INVALID_CREDENTIALS');

    const valid = await bcrypt.compare(password, user.password);
    if (!valid) throw new AppError('Invalid email or password', 401, 'INVALID_CREDENTIALS');

    // Banned users blocked at login — middleware only verifies JWT
    if (user.isBanned) throw new AppError('Your account has been suspended.', 403, 'BANNED');

    return { token: signToken(user), user: toPublicUser(user) };
  },
};
