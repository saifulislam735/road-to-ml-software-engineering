import { Navigate, Outlet } from 'react-router-dom';
import { useAuthStore } from '../store/authStore';
import Spinner from './ui/Spinner';

export default function ProtectedRoute() {
  const { isAuthenticated, hydrated } = useAuthStore();
  if (!hydrated) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Spinner size="lg" className="text-brand-600" />
      </div>
    );
  }
  return isAuthenticated ? <Outlet /> : <Navigate to="/login" replace />;
}
