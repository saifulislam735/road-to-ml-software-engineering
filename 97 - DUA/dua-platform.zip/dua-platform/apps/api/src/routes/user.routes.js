import { Router } from 'express';
import { z } from 'zod';
import { userController } from '../controllers/user.controller.js';
import { authMiddleware } from '../middleware/auth.middleware.js';
import { validate } from '../middleware/validate.middleware.js';

const updateMeSchema = z.object({
  name: z.string().max(50).nullable().optional(),
  bio: z.string().max(200).nullable().optional(),
  avatarUrl: z.string().url().nullable().optional(),
  isPaused: z.boolean().optional(),
  username: z.string().min(3).max(30).regex(/^[a-zA-Z0-9_]+$/).optional(),
});

const router = Router();

router.patch('/me', authMiddleware, validate(updateMeSchema), userController.updateMe);
router.get('/:username', userController.getPublicProfile);

export default router;
