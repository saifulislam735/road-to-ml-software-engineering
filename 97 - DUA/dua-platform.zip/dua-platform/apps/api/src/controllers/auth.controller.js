import { catchAsync } from '../utils/catchAsync.js';
import { authService } from '../services/auth.service.js';

export const authController = {
  register: catchAsync(async (req, res) => {
    const result = await authService.register(req.body);
    res.status(201).json(result);
  }),

  login: catchAsync(async (req, res) => {
    const result = await authService.login(req.body);
    res.json(result);
  }),

  logout: catchAsync(async (req, res) => {
    // Stateless JWT — client discards the token
    res.json({ success: true });
  }),
};
