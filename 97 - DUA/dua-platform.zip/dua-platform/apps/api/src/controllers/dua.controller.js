import { catchAsync } from '../utils/catchAsync.js';
import { duaService } from '../services/dua.service.js';

export const duaController = {
  send: catchAsync(async (req, res) => {
    const result = await duaService.send(req.params.username, req.body.message);
    res.status(201).json(result);
  }),

  inbox: catchAsync(async (req, res) => {
    const page = parseInt(req.query.page || '1', 10);
    const limit = parseInt(req.query.limit || '20', 10);
    const unreadOnly = req.query.unreadOnly === 'true';
    const result = await duaService.getInbox(req.user.id, { page, limit, unreadOnly });
    res.json(result);
  }),

  markRead: catchAsync(async (req, res) => {
    const result = await duaService.markRead(req.user.id, req.params.id);
    res.json(result);
  }),

  delete: catchAsync(async (req, res) => {
    const result = await duaService.delete(req.user.id, req.params.id);
    res.json(result);
  }),

  report: catchAsync(async (req, res) => {
    const result = await duaService.report(req.params.id, req.body.reason);
    res.status(201).json(result);
  }),
};
