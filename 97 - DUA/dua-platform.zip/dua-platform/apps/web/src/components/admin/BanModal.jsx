import { useState } from 'react';
import Button from '../ui/Button';
import Textarea from '../ui/Textarea';

export default function BanModal({ isOpen, onClose, onConfirm, username, isLoading }) {
  const [reason, setReason] = useState('');
  const [error, setError] = useState('');

  if (!isOpen) return null;

  const handleConfirm = () => {
    if (reason.trim().length < 10) {
      setError('Reason must be at least 10 characters');
      return;
    }
    setError('');
    onConfirm(reason.trim());
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center px-4">
      <div className="absolute inset-0 bg-black/40" onClick={onClose} />
      <div className="relative bg-white rounded-xl shadow-lg max-w-sm w-full p-6">
        <h2 className="font-semibold text-gray-900">Ban @{username}</h2>
        <p className="text-sm text-gray-500 mt-1">This user will no longer be able to log in.</p>
        <div className="mt-4">
          <Textarea
            rows={3}
            placeholder="Reason for ban (required)"
            value={reason}
            onChange={(e) => setReason(e.target.value)}
            error={error}
          />
        </div>
        <div className="flex gap-2 mt-4 justify-end">
          <Button variant="secondary" onClick={onClose}>Cancel</Button>
          <Button variant="danger" onClick={handleConfirm} isLoading={isLoading}>Ban user</Button>
        </div>
      </div>
    </div>
  );
}
