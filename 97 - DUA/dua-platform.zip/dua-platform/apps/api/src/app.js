import express from 'express';
import helmet from 'helmet';
import cors from 'cors';
import { env } from './config/env.js';
import authRoutes from './routes/auth.routes.js';
import userRoutes from './routes/user.routes.js';
import duaRoutes from './routes/dua.routes.js';
import adminRoutes from './routes/admin.routes.js';

const app = express();

// Behind nginx in production — trust X-Forwarded-For so rate limiting uses real client IP
app.set('trust proxy', 1);

app.use(helmet());
app.use(cors({ origin: env.corsOrigin, credentials: true }));
app.use(express.json({ limit: '100kb' }));

// Health check (Docker + Uptime Kuma)
app.get('/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString(), uptime: process.uptime() });
});

app.use('/api/auth', authRoutes);
app.use('/api/users', userRoutes);
app.use('/api/duas', duaRoutes);
app.use('/api/admin', adminRoutes);

// 404
app.use((req, res) => {
  res.status(404).json({ error: true, message: 'Route not found', code: 'NOT_FOUND' });
});

// Global error handler
app.use((err, req, res, next) => {
  const status = err.statusCode || 500;
  if (status >= 500) console.error(err);
  res.status(status).json({
    error: true,
    message: status >= 500 ? 'Something went wrong' : err.message,
    ...(err.code ? { code: err.code } : {}),
  });
});

app.listen(env.port, () => {
  console.log(`API running on port ${env.port} [${env.nodeEnv}]`);
});

export default app;
