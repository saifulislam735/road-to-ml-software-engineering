import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import toast from 'react-hot-toast';
import Textarea from './ui/Textarea';
import Button from './ui/Button';
import { useSendDua } from '../hooks/useDuas';
import { apiError } from '../utils/helpers';

const schema = z.object({
  message: z
    .string()
    .min(10, 'Please write at least 10 characters')
    .max(500, 'Maximum 500 characters'),
});

export default function DuaForm({ username, name }) {
  const [sent, setSent] = useState(false);
  const sendDua = useSendDua(username);
  const {
    register, handleSubmit, watch, reset,
    formState: { errors },
  } = useForm({ resolver: zodResolver(schema), defaultValues: { message: '' } });

  const message = watch('message') || '';

  const onSubmit = (data) => {
    sendDua.mutate(data, {
      onSuccess: () => {
        setSent(true);
        setTimeout(() => reset(), 400);
      },
      onError: (err) => {
        if (err.response?.status === 429) {
          toast.error("You've sent too many duas recently. Try again later.");
        } else {
          toast.error(apiError(err));
        }
      },
    });
  };

  if (sent) {
    return (
      <div className="bg-brand-50 border border-brand-100 rounded-xl p-6 text-center animate-[pop_0.4s_ease]">
        <style>{`@keyframes pop { 0% { transform: scale(0.95); opacity: 0; } 100% { transform: scale(1); opacity: 1; } }`}</style>
        <div className="text-4xl mb-2">🤲</div>
        <p className="font-semibold text-brand-700">Your dua has been sent</p>
        <p className="text-sm text-gray-500 mt-1">May it be accepted. Jazakallahu khairan.</p>
        <button onClick={() => setSent(false)} className="mt-4 text-sm text-brand-600 font-medium hover:underline">
          Send another dua
        </button>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-3">
      <Textarea
        rows={4}
        maxLength={500}
        placeholder={`Write a dua for ${name || username}...`}
        error={errors.message?.message}
        {...register('message')}
      />
      <div className="flex items-center justify-between">
        <span className="text-xs text-gray-400">{message.length} / 500</span>
      </div>
      <Button type="submit" isLoading={sendDua.isPending} className="w-full">
        Send dua 🤲
      </Button>
      <p className="text-xs text-gray-400 text-center">Your message is anonymous</p>
    </form>
  );
}
