import { AppError } from '../utils/AppError.js';
import { duaRepo } from '../repositories/dua.repo.js';
import { userRepo } from '../repositories/user.repo.js';

export const duaService = {
  async send(username, message) {
    const owner = await userRepo.findByUsername(username);
    if (!owner || owner.isBanned) throw new AppError('User not found', 404, 'NOT_FOUND');
    if (owner.isPaused) {
      throw new AppError('This user is not accepting duas right now.', 403, 'PAUSED');
    }
    const dua = await duaRepo.create({ message, ownerId: owner.id });
    return { id: dua.id, createdAt: dua.createdAt };
  },

  async getInbox(ownerId, { page = 1, limit = 20, unreadOnly = false }) {
    const take = Math.min(Math.max(limit, 1), 50);
    const skip = (Math.max(page, 1) - 1) * take;
    const [duas, total] = await Promise.all([
      duaRepo.findInbox({ ownerId, skip, take, unreadOnly }),
      duaRepo.countInbox({ ownerId, unreadOnly }),
    ]);
    return {
      duas,
      pagination: { page, limit: take, total, totalPages: Math.ceil(total / take) || 1 },
    };
  },

  async markRead(userId, duaId) {
    const dua = await duaRepo.findById(duaId);
    if (!dua) throw new AppError('Dua not found', 404, 'NOT_FOUND');
    if (dua.ownerId !== userId) throw new AppError('Not authorized', 403, 'FORBIDDEN');
    await duaRepo.markRead(duaId);
    return { success: true };
  },

  async delete(userId, duaId) {
    const dua = await duaRepo.findById(duaId);
    if (!dua) throw new AppError('Dua not found', 404, 'NOT_FOUND');
    if (dua.ownerId !== userId) throw new AppError('Not authorized', 403, 'FORBIDDEN');
    await duaRepo.delete(duaId);
    return { success: true };
  },

  async report(duaId, reason, reporterId = null) {
    const dua = await duaRepo.findById(duaId);
    if (!dua) throw new AppError('Dua not found', 404, 'NOT_FOUND');
    const report = await duaRepo.createReport({ duaId, reason, reporterId });
    return { id: report.id };
  },
};
