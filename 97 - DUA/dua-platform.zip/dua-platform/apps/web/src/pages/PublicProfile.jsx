import { useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { userApi } from '../services/api';
import Avatar from '../components/ui/Avatar';
import Spinner from '../components/ui/Spinner';
import DuaForm from '../components/DuaForm';

export default function PublicProfile() {
  const { username } = useParams();
  const { data: profile, isLoading, error } = useQuery({
    queryKey: ['profile', username],
    queryFn: () => userApi.getProfile(username).then((r) => r.data),
    retry: false,
  });

  useEffect(() => {
    if (profile) {
      document.title = `Send a dua to ${profile.name || profile.username}`;
    }
    return () => { document.title = 'Dua — Receive duas from your loved ones, anonymously'; };
  }, [profile]);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Spinner size="lg" className="text-brand-600" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center px-4 text-center">
        <div className="text-4xl mb-3">🤲</div>
        <h1 className="text-lg font-semibold text-gray-900">User not found</h1>
        <p className="text-sm text-gray-500 mt-1">This profile doesn't exist or is unavailable.</p>
        <Link to="/" className="mt-4 text-brand-600 font-medium hover:underline text-sm">Go home</Link>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-brand-50 to-white px-4 py-10">
      <div className="max-w-lg mx-auto">
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 text-center">
          <Avatar src={profile.avatarUrl} name={profile.name || profile.username} size="lg" className="mx-auto" />
          <h1 className="mt-3 text-xl font-semibold text-gray-900">{profile.name || `@${profile.username}`}</h1>
          {profile.name && <p className="text-sm text-gray-400">@{profile.username}</p>}
          {profile.bio && <p className="mt-2 text-gray-600">{profile.bio}</p>}
        </div>

        <div className="mt-6 bg-white rounded-xl shadow-sm border border-gray-100 p-6">
          {profile.isPaused ? (
            <p className="text-center text-gray-500">This user is not accepting duas right now.</p>
          ) : (
            <DuaForm username={profile.username} name={profile.name} />
          )}
        </div>

        <p className="text-center text-xs text-gray-400 mt-8">
          Want your own dua link?{' '}
          <Link to="/register" className="text-brand-600 font-medium hover:underline">Create yours →</Link>
        </p>
      </div>
    </div>
  );
}
