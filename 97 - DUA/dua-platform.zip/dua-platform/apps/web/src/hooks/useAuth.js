import { useMutation } from '@tanstack/react-query';
import { authApi } from '../services/api';
import { useAuthStore } from '../store/authStore';

export function useLogin() {
  const login = useAuthStore((s) => s.login);
  return useMutation({
    mutationFn: (data) => authApi.login(data).then((r) => r.data),
    onSuccess: ({ token, user }) => login(token, user),
  });
}

export function useRegister() {
  const login = useAuthStore((s) => s.login);
  return useMutation({
    mutationFn: (data) => authApi.register(data).then((r) => r.data),
    onSuccess: ({ token, user }) => login(token, user),
  });
}
