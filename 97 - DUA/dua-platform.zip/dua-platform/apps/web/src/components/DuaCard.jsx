import { useState } from 'react';
import { Trash2 } from 'lucide-react';
import { relativeTime } from '../utils/helpers';

export default function DuaCard({ dua, onDelete, isDeleting }) {
  const [expanded, setExpanded] = useState(false);
  const [confirming, setConfirming] = useState(false);

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-4 animate-[fadeIn_0.3s_ease]">
      <style>{`@keyframes fadeIn { from { opacity: 0; transform: translateY(4px); } to { opacity: 1; transform: none; } }`}</style>
      <div className="flex items-start gap-3">
        {!dua.isRead && <span className="mt-1.5 w-2 h-2 rounded-full bg-brand-500 shrink-0" aria-label="Unread" />}
        <div className="flex-1 min-w-0">
          <p
            className={`text-gray-800 whitespace-pre-wrap cursor-pointer ${expanded ? '' : 'line-clamp-3'}`}
            onClick={() => setExpanded((e) => !e)}
          >
            {dua.message}
          </p>
          <p className="text-xs text-gray-400 mt-2">{relativeTime(dua.createdAt)}</p>
        </div>
        <div className="shrink-0">
          {confirming ? (
            <div className="flex gap-1">
              <button
                onClick={() => onDelete(dua.id)}
                disabled={isDeleting}
                className="text-xs px-2 py-1 rounded bg-red-600 text-white disabled:opacity-50"
              >
                Delete
              </button>
              <button
                onClick={() => setConfirming(false)}
                className="text-xs px-2 py-1 rounded bg-gray-100 text-gray-600"
              >
                Cancel
              </button>
            </div>
          ) : (
            <button
              onClick={() => setConfirming(true)}
              className="text-gray-300 hover:text-red-500 p-1"
              aria-label="Delete dua"
            >
              <Trash2 size={16} />
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
