import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import toast from 'react-hot-toast';
import { Copy } from 'lucide-react';
import Navbar from '../components/Navbar';
import Input from '../components/ui/Input';
import Textarea from '../components/ui/Textarea';
import Button from '../components/ui/Button';
import { useAuthStore } from '../store/authStore';
import { userApi } from '../services/api';
import { useMutation } from '@tanstack/react-query';
import { copyToClipboard, apiError } from '../utils/helpers';

const schema = z.object({
  name: z.string().max(50).optional().or(z.literal('')),
  bio: z.string().max(200).optional().or(z.literal('')),
  username: z
    .string()
    .min(3, 'At least 3 characters')
    .max(30)
    .regex(/^[a-zA-Z0-9_]+$/, 'Only letters, numbers and underscores'),
  isPaused: z.boolean(),
});

export default function Settings() {
  const { user, setUser } = useAuthStore();
  const appUrl = import.meta.env.VITE_APP_URL || window.location.origin;
  const profileUrl = `${appUrl}/u/${user?.username}`;

  const { register, handleSubmit, formState: { errors } } = useForm({
    resolver: zodResolver(schema),
    defaultValues: {
      name: user?.name || '',
      bio: user?.bio || '',
      username: user?.username || '',
      isPaused: user?.isPaused || false,
    },
  });

  const update = useMutation({
    mutationFn: (data) => userApi.updateMe(data).then((r) => r.data.user),
    onSuccess: (updated) => {
      setUser(updated);
      toast.success('Profile updated');
    },
    onError: (err) => toast.error(apiError(err)),
  });

  const onSubmit = (data) => {
    update.mutate({
      name: data.name || null,
      bio: data.bio || null,
      username: data.username,
      isPaused: data.isPaused,
    });
  };

  const handleCopy = async () => {
    await copyToClipboard(profileUrl);
    toast.success('Link copied!');
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      <main className="max-w-lg mx-auto px-4 py-6 space-y-6">
        <h1 className="text-xl font-semibold text-gray-900">Settings</h1>

        <form onSubmit={handleSubmit(onSubmit)} className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 space-y-4">
          <Input label="Name" placeholder="Your display name" error={errors.name?.message} {...register('name')} />
          <Textarea label="Bio" rows={3} maxLength={200} placeholder="Send me a dua 🤲" error={errors.bio?.message} {...register('bio')} />
          <Input label="Username" error={errors.username?.message} {...register('username')} />

          <label className="flex items-center justify-between py-2 cursor-pointer">
            <div>
              <p className="text-sm font-medium text-gray-700">Pause receiving duas</p>
              <p className="text-xs text-gray-400">Visitors won't be able to send you duas</p>
            </div>
            <input type="checkbox" className="w-5 h-5 accent-brand-600" {...register('isPaused')} />
          </label>

          <Button type="submit" isLoading={update.isPending} className="w-full">Save changes</Button>
        </form>

        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
          <p className="text-sm font-medium text-gray-700 mb-2">Your profile link</p>
          <div className="flex gap-2">
            <input
              readOnly
              value={profileUrl}
              className="flex-1 h-11 px-3 rounded-lg border border-gray-300 bg-gray-50 text-sm text-gray-600 min-w-0"
            />
            <Button type="button" variant="secondary" onClick={handleCopy} className="shrink-0">
              <Copy size={16} />
            </Button>
          </div>
        </div>
      </main>
    </div>
  );
}
