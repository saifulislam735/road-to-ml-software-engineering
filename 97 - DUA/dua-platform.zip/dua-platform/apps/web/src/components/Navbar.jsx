import { Link, NavLink, useNavigate } from 'react-router-dom';
import { Inbox, Settings, Share2, LogOut, ShieldCheck } from 'lucide-react';
import { useAuthStore } from '../store/authStore';

export default function Navbar() {
  const { user, logout } = useAuthStore();
  const navigate = useNavigate();

  const linkClass = ({ isActive }) =>
    `flex items-center gap-1.5 px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
      isActive ? 'bg-brand-100 text-brand-700' : 'text-gray-600 hover:bg-gray-100'
    }`;

  return (
    <nav className="bg-white border-b border-gray-200 sticky top-0 z-10">
      <div className="max-w-lg mx-auto px-4 h-14 flex items-center justify-between">
        <Link to="/inbox" className="font-semibold text-brand-700">
          Dua 🤲
        </Link>
        <div className="flex items-center gap-1">
          <NavLink to="/inbox" className={linkClass}>
            <Inbox size={16} /> <span className="hidden sm:inline">Inbox</span>
          </NavLink>
          <NavLink to="/share" className={linkClass}>
            <Share2 size={16} /> <span className="hidden sm:inline">Share</span>
          </NavLink>
          <NavLink to="/settings" className={linkClass}>
            <Settings size={16} /> <span className="hidden sm:inline">Settings</span>
          </NavLink>
          {user?.role === 'ADMIN' && (
            <NavLink to="/admin" className={linkClass}>
              <ShieldCheck size={16} /> <span className="hidden sm:inline">Admin</span>
            </NavLink>
          )}
          <button
            onClick={() => { logout(); navigate('/login'); }}
            className="flex items-center gap-1.5 px-3 py-2 rounded-lg text-sm text-gray-500 hover:bg-gray-100"
            title="Log out"
          >
            <LogOut size={16} />
          </button>
        </div>
      </div>
    </nav>
  );
}
