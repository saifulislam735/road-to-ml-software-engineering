import { useState } from 'react';
import { Link } from 'react-router-dom';
import { CheckCircle2 } from 'lucide-react';
import toast from 'react-hot-toast';
import {
  useAdminReports, useAdminStats, useResolveReport, useDismissReport,
} from '../../hooks/useAdmin';
import Badge from '../../components/ui/Badge';
import Button from '../../components/ui/Button';
import Spinner from '../../components/ui/Spinner';
import { relativeTime, truncate, apiError } from '../../utils/helpers';

const TABS = [
  { key: 'pending', label: 'Pending' },
  { key: 'resolved', label: 'Resolved' },
  { key: 'dismissed', label: 'Dismissed' },
];

export default function AdminReports() {
  const [tab, setTab] = useState('pending');
  const [page, setPage] = useState(1);
  const { data: stats } = useAdminStats();
  const pendingCount = stats?.reports?.pending ?? 0;

  const { data, isLoading, error, refetch } = useAdminReports({ page, limit: 20, status: tab });
  const resolveReport = useResolveReport();
  const dismissReport = useDismissReport();
  const [actingId, setActingId] = useState(null);

  const reports = data?.reports ?? [];
  const pagination = data?.pagination;

  const switchTab = (key) => { setTab(key); setPage(1); };

  const handleResolve = (id) => {
    setActingId(id);
    resolveReport.mutate(
      { id, hideDua: true },
      {
        onSuccess: () => toast.success('Report resolved, dua hidden'),
        onError: (e) => toast.error(apiError(e)),
        onSettled: () => setActingId(null),
      }
    );
  };

  const handleDismiss = (id) => {
    setActingId(id);
    dismissReport.mutate(id, {
      onSuccess: () => toast.success('Report dismissed'),
      onError: (e) => toast.error(apiError(e)),
      onSettled: () => setActingId(null),
    });
  };

  return (
    <div className="space-y-4">
      <h1 className="text-xl font-semibold text-gray-900">Reports</h1>

      <div className="flex gap-1 bg-gray-100 rounded-lg p-1 w-fit">
        {TABS.map((t) => (
          <button
            key={t.key}
            onClick={() => switchTab(t.key)}
            className={`px-4 py-1.5 rounded-md text-sm font-medium transition-colors ${
              tab === t.key ? 'bg-white shadow-sm text-gray-900' : 'text-gray-500 hover:text-gray-700'
            }`}
          >
            {t.label}
            {t.key === 'pending' && pendingCount > 0 && (
              <span className="ml-1.5 inline-flex items-center justify-center min-w-[1.25rem] h-5 px-1 rounded-full bg-red-500 text-white text-xs">
                {pendingCount}
              </span>
            )}
          </button>
        ))}
      </div>

      {isLoading ? (
        <div className="flex justify-center py-16"><Spinner /></div>
      ) : error ? (
        <div className="bg-red-50 border border-red-100 rounded-xl p-6 text-center">
          <p className="text-sm text-red-700 mb-3">Failed to load reports.</p>
          <Button variant="secondary" onClick={refetch}>Retry</Button>
        </div>
      ) : reports.length === 0 ? (
        tab === 'pending' ? (
          <div className="bg-white rounded-xl border border-gray-100 p-12 text-center">
            <CheckCircle2 className="mx-auto text-brand-500" size={40} />
            <p className="mt-3 text-sm text-gray-500">All clear — no pending reports.</p>
          </div>
        ) : (
          <div className="bg-white rounded-xl border border-gray-100 p-10 text-center text-sm text-gray-400">
            No {tab} reports.
          </div>
        )
      ) : (
        <div className="space-y-3">
          {reports.map((report) => (
            <div key={report.id} className="bg-white rounded-xl border border-gray-100 shadow-sm p-5">
              <div className="flex items-start justify-between gap-3">
                <p className="text-xs font-medium uppercase text-gray-400">Reported dua</p>
                <span className="text-xs text-gray-400 whitespace-nowrap">{relativeTime(report.createdAt)}</span>
              </div>
              <p className="mt-1 text-sm text-gray-800 italic">
                “{truncate(report.dua?.message ?? '(dua deleted)', 200)}”
              </p>
              <p className="mt-3 text-sm text-gray-600">
                <span className="font-medium text-gray-700">Reason:</span> {report.reason}
              </p>
              <p className="mt-1 text-sm text-gray-600">
                <span className="font-medium text-gray-700">Sent to:</span>{' '}
                {report.dua?.owner ? (
                  <Link to={`/admin/users/${report.dua.owner.id}`} className="text-brand-700 hover:underline">
                    @{report.dua.owner.username}
                  </Link>
                ) : (
                  <span className="text-gray-400">unknown</span>
                )}
                {report.dua?.isHidden && <Badge color="orange" className="ml-2">Dua hidden</Badge>}
              </p>

              {tab === 'pending' ? (
                <div className="flex flex-wrap gap-2 mt-4">
                  <Button
                    onClick={() => handleResolve(report.id)}
                    isLoading={actingId === report.id && resolveReport.isPending}
                  >
                    Resolve + hide dua
                  </Button>
                  <Button
                    variant="secondary"
                    onClick={() => handleDismiss(report.id)}
                    isLoading={actingId === report.id && dismissReport.isPending}
                  >
                    Dismiss
                  </Button>
                </div>
              ) : (
                <div className="mt-4">
                  <Badge color={tab === 'resolved' ? 'green' : 'gray'}>
                    {tab === 'resolved' ? 'Resolved' : 'Dismissed'}
                  </Badge>
                </div>
              )}
            </div>
          ))}

          {pagination && pagination.totalPages > 1 && (
            <div className="flex items-center justify-between text-sm pt-2">
              <button
                className="px-3 py-1.5 rounded-lg border border-gray-300 bg-white disabled:opacity-40"
                disabled={pagination.page <= 1}
                onClick={() => setPage(pagination.page - 1)}
              >
                Prev
              </button>
              <span className="text-gray-500">Page {pagination.page} of {pagination.totalPages}</span>
              <button
                className="px-3 py-1.5 rounded-lg border border-gray-300 bg-white disabled:opacity-40"
                disabled={pagination.page >= pagination.totalPages}
                onClick={() => setPage(pagination.page + 1)}
              >
                Next
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
