-- ============================================================
-- FitTrack — FULL database schema for Neon PostgreSQL
-- 19 tables + migration + 8 indexes.
-- Generated from js/db.js SCHEMA_STATEMENTS (always in sync).
--
-- You can run this manually in the Neon SQL Editor, OR let the
-- app run the identical statements via the setup wizard /
-- Profile -> Database -> "Initialize Tables". Both are safe to
-- repeat (everything is IF NOT EXISTS).
-- ============================================================

CREATE TABLE IF NOT EXISTS app_config (
    key VARCHAR(100) PRIMARY KEY,
    value TEXT,
    updated_at TIMESTAMP DEFAULT NOW()
  );

CREATE TABLE IF NOT EXISTS admins (
    id SERIAL PRIMARY KEY,
    username VARCHAR(100) UNIQUE,
    password_hash VARCHAR(255),
    created_at TIMESTAMP DEFAULT NOW()
  );

CREATE TABLE IF NOT EXISTS users (
    id SERIAL PRIMARY KEY,
    email VARCHAR(255) UNIQUE,
    name VARCHAR(255),
    avatar VARCHAR(10) DEFAULT '💪',
    created_at TIMESTAMP DEFAULT NOW()
  );

CREATE TABLE IF NOT EXISTS profiles (
    user_id INTEGER PRIMARY KEY REFERENCES users(id),
    height_cm FLOAT, weight_kg FLOAT, age INTEGER,
    goal VARCHAR(50), activity_level VARCHAR(50),
    bmr FLOAT, tdee FLOAT,
    protein_target FLOAT, calorie_target FLOAT,
    units VARCHAR(10) DEFAULT 'metric',
    rest_timer_default INTEGER DEFAULT 60,
    week_starts VARCHAR(10) DEFAULT 'monday',
    updated_at TIMESTAMP DEFAULT NOW()
  );

CREATE TABLE IF NOT EXISTS exercises (
    id VARCHAR(100) PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    name_bn VARCHAR(255),
    muscle_primary VARCHAR(100),
    muscle_secondary TEXT[],
    equipment VARCHAR(100),
    is_home_friendly BOOLEAN DEFAULT FALSE,
    difficulty VARCHAR(20),
    category VARCHAR(50),
    image_url TEXT,
    image_url_2 TEXT,
    image_url_3 TEXT,
    instructions TEXT[],
    instructions_bn TEXT[],
    mistakes TEXT[],
    mistakes_bn TEXT[],
    tips TEXT[],
    tips_bn TEXT[],
    sets_strength VARCHAR(20),
    sets_hypertrophy VARCHAR(20),
    sets_endurance VARCHAR(20),
    calories_per_30min INTEGER,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
  );

CREATE TABLE IF NOT EXISTS warmup_steps (
    id SERIAL PRIMARY KEY,
    order_index INTEGER,
    name VARCHAR(255),
    name_bn VARCHAR(255),
    duration_seconds INTEGER,
    instruction TEXT,
    instruction_bn TEXT,
    image_url TEXT,
    is_active BOOLEAN DEFAULT TRUE
  );

CREATE TABLE IF NOT EXISTS plans (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id),
    name VARCHAR(255),
    split_type VARCHAR(50),
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT NOW()
  );

CREATE TABLE IF NOT EXISTS plan_days (
    id SERIAL PRIMARY KEY,
    plan_id INTEGER REFERENCES plans(id) ON DELETE CASCADE,
    day_of_week INTEGER,
    workout_type VARCHAR(50),
    notes TEXT
  );

CREATE TABLE IF NOT EXISTS plan_exercises (
    id SERIAL PRIMARY KEY,
    plan_day_id INTEGER REFERENCES plan_days(id) ON DELETE CASCADE,
    exercise_id VARCHAR(100) REFERENCES exercises(id),
    order_index INTEGER,
    target_sets INTEGER DEFAULT 3,
    target_reps VARCHAR(20) DEFAULT '10',
    target_weight FLOAT
  );

CREATE TABLE IF NOT EXISTS sessions (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id),
    date DATE NOT NULL,
    workout_type VARCHAR(50),
    started_at TIMESTAMP,
    ended_at TIMESTAMP,
    duration_minutes INTEGER,
    total_volume_kg FLOAT DEFAULT 0,
    calories_burned INTEGER DEFAULT 0,
    notes TEXT,
    mood_rating INTEGER,
    plan_day_id INTEGER REFERENCES plan_days(id)
  );

CREATE TABLE IF NOT EXISTS session_sets (
    id SERIAL PRIMARY KEY,
    session_id INTEGER REFERENCES sessions(id) ON DELETE CASCADE,
    exercise_id VARCHAR(100),
    set_number INTEGER,
    weight_kg FLOAT DEFAULT 0,
    reps INTEGER DEFAULT 0,
    rpe INTEGER,
    completed BOOLEAN DEFAULT FALSE,
    rest_taken_seconds INTEGER
  );

CREATE TABLE IF NOT EXISTS personal_records (
    user_id INTEGER REFERENCES users(id),
    exercise_id VARCHAR(100) REFERENCES exercises(id),
    best_weight_kg FLOAT DEFAULT 0,
    best_reps INTEGER DEFAULT 0,
    best_volume FLOAT DEFAULT 0,
    achieved_at DATE,
    PRIMARY KEY (user_id, exercise_id)
  );

CREATE TABLE IF NOT EXISTS meal_logs (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id),
    date DATE NOT NULL,
    meal_type VARCHAR(20),
    food_name VARCHAR(255),
    calories FLOAT DEFAULT 0,
    protein_g FLOAT DEFAULT 0,
    carbs_g FLOAT DEFAULT 0,
    fat_g FLOAT DEFAULT 0,
    quantity FLOAT DEFAULT 1,
    unit VARCHAR(50) DEFAULT 'serving'
  );

CREATE TABLE IF NOT EXISTS foods (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255),
    name_bn VARCHAR(255),
    calories_per_100g FLOAT,
    protein_per_100g FLOAT,
    carbs_per_100g FLOAT,
    fat_per_100g FLOAT,
    category VARCHAR(100),
    is_active BOOLEAN DEFAULT TRUE
  );

CREATE TABLE IF NOT EXISTS meal_templates (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255),
    goal VARCHAR(50),
    total_calories INTEGER,
    total_protein INTEGER,
    description TEXT,
    meals JSONB,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT NOW()
  );

CREATE TABLE IF NOT EXISTS body_metrics (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id),
    date DATE NOT NULL,
    weight_kg FLOAT,
    body_fat_pct FLOAT,
    notes TEXT
  );

CREATE TABLE IF NOT EXISTS blog_posts (
    id SERIAL PRIMARY KEY,
    title VARCHAR(500),
    slug VARCHAR(500) UNIQUE,
    excerpt TEXT,
    content TEXT,
    content_bn TEXT,
    cover_image_url TEXT,
    category VARCHAR(100),
    tags TEXT[],
    is_published BOOLEAN DEFAULT FALSE,
    published_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
  );

CREATE TABLE IF NOT EXISTS guides (
    id SERIAL PRIMARY KEY,
    title VARCHAR(500),
    category VARCHAR(100),
    content TEXT,
    content_bn TEXT,
    cover_image_url TEXT,
    order_index INTEGER DEFAULT 0,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT NOW()
  );

CREATE TABLE IF NOT EXISTS ai_conversations (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id),
    role VARCHAR(10),
    message TEXT,
    model_used VARCHAR(100),
    created_at TIMESTAMP DEFAULT NOW()
  );

ALTER TABLE blog_posts ADD COLUMN IF NOT EXISTS content_bn TEXT;

CREATE INDEX IF NOT EXISTS idx_sessions_user_date ON sessions (user_id, date);

CREATE INDEX IF NOT EXISTS idx_session_sets_session ON session_sets (session_id);

CREATE INDEX IF NOT EXISTS idx_session_sets_exercise ON session_sets (exercise_id);

CREATE INDEX IF NOT EXISTS idx_meal_logs_user_date ON meal_logs (user_id, date);

CREATE INDEX IF NOT EXISTS idx_body_metrics_user_date ON body_metrics (user_id, date);

CREATE INDEX IF NOT EXISTS idx_plan_days_plan ON plan_days (plan_id);

CREATE INDEX IF NOT EXISTS idx_plan_exercises_day ON plan_exercises (plan_day_id);

CREATE INDEX IF NOT EXISTS idx_ai_conversations_user ON ai_conversations (user_id, created_at);
