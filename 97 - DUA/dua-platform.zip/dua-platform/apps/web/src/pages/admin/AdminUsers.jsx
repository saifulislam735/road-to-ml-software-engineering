import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';
import { RefreshCw } from 'lucide-react';
import { useQueryClient } from '@tanstack/react-query';
import AdminTable from '../../components/admin/AdminTable';
import BanModal from '../../components/admin/BanModal';
import Avatar from '../../components/ui/Avatar';
import Badge from '../../components/ui/Badge';
import { useAdminUsers, useBanUser, useUnbanUser } from '../../hooks/useAdmin';
import { relativeTime, apiError } from '../../utils/helpers';

export default function AdminUsers() {
  const navigate = useNavigate();
  const qc = useQueryClient();
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState('');
  const [debounced, setDebounced] = useState('');
  const [filter, setFilter] = useState('all'); // all | active | banned
  const [banTarget, setBanTarget] = useState(null);
  const [unbanConfirm, setUnbanConfirm] = useState(null);

  useEffect(() => {
    const t = setTimeout(() => { setDebounced(search); setPage(1); }, 300);
    return () => clearTimeout(t);
  }, [search]);

  const params = {
    page,
    limit: 20,
    ...(debounced ? { search: debounced } : {}),
    ...(filter === 'banned' ? { banned: 'true' } : filter === 'active' ? { banned: 'false' } : {}),
  };

  const { data, isLoading, error, refetch } = useAdminUsers(params);
  const banUser = useBanUser();
  const unbanUser = useUnbanUser();

  const handleBan = (reason) => {
    banUser.mutate(
      { id: banTarget.id, reason },
      {
        onSuccess: () => { toast.success(`@${banTarget.username} banned`); setBanTarget(null); },
        onError: (err) => toast.error(apiError(err)),
      }
    );
  };

  const handleUnban = (user) => {
    unbanUser.mutate(user.id, {
      onSuccess: () => { toast.success(`@${user.username} unbanned`); setUnbanConfirm(null); },
      onError: (err) => toast.error(apiError(err)),
    });
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-2">
        <input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search username or email..."
          className="h-10 px-3 rounded-lg border border-gray-300 bg-white text-sm w-full sm:w-64 focus:outline-none focus:ring-2 focus:ring-brand-500"
        />
        <select
          value={filter}
          onChange={(e) => { setFilter(e.target.value); setPage(1); }}
          className="h-10 px-3 rounded-lg border border-gray-300 bg-white text-sm"
        >
          <option value="all">All</option>
          <option value="active">Active</option>
          <option value="banned">Banned</option>
        </select>
        <button
          onClick={() => { qc.invalidateQueries({ queryKey: ['admin', 'users'] }); }}
          className="h-10 px-3 rounded-lg border border-gray-300 bg-white text-gray-500 hover:text-gray-700"
          title="Refresh"
        >
          <RefreshCw size={16} />
        </button>
      </div>

      <AdminTable
        isLoading={isLoading}
        error={error}
        onRetry={refetch}
        isEmpty={data?.users?.length === 0}
        emptyMessage="No users found."
        pagination={data?.pagination}
        onPageChange={setPage}
      >
        <table className="w-full text-sm">
          <thead>
            <tr className="text-left text-xs text-gray-400 uppercase tracking-wide border-b border-gray-100">
              <th className="py-2 px-4">User</th>
              <th className="py-2 px-4">Joined</th>
              <th className="py-2 px-4">Duas</th>
              <th className="py-2 px-4">Status</th>
              <th className="py-2 px-4 text-right">Actions</th>
            </tr>
          </thead>
          <tbody>
            {data?.users?.map((u, i) => (
              <tr
                key={u.id}
                className={`${i % 2 ? 'bg-gray-50' : ''} hover:bg-brand-50/40 cursor-pointer`}
                onClick={() => navigate(`/admin/users/${u.id}`)}
              >
                <td className="py-2 px-4">
                  <div className="flex items-center gap-2">
                    <Avatar src={u.avatarUrl} name={u.name || u.username} size="sm" />
                    <div>
                      <p className="font-medium text-gray-800">@{u.username}</p>
                      <p className="text-xs text-gray-400">{u.email}</p>
                    </div>
                  </div>
                </td>
                <td className="py-2 px-4 text-gray-500">{relativeTime(u.createdAt)}</td>
                <td className="py-2 px-4">{u.duasReceived}</td>
                <td className="py-2 px-4">
                  {u.isBanned ? <Badge color="red">Banned</Badge> : <Badge color="green">Active</Badge>}
                </td>
                <td className="py-2 px-4 text-right" onClick={(e) => e.stopPropagation()}>
                  <div className="inline-flex gap-2">
                    <button
                      onClick={() => navigate(`/admin/users/${u.id}`)}
                      className="text-xs px-2 py-1 rounded border border-gray-300 hover:bg-gray-50"
                    >
                      View
                    </button>
                    {u.role !== 'ADMIN' && (
                      u.isBanned ? (
                        unbanConfirm === u.id ? (
                          <span className="inline-flex gap-1 items-center text-xs">
                            Confirm?
                            <button onClick={() => handleUnban(u)} className="px-2 py-1 rounded bg-brand-600 text-white">Yes</button>
                            <button onClick={() => setUnbanConfirm(null)} className="px-2 py-1 rounded bg-gray-100">No</button>
                          </span>
                        ) : (
                          <button onClick={() => setUnbanConfirm(u.id)} className="text-xs px-2 py-1 rounded border border-gray-300 hover:bg-gray-50">
                            Unban
                          </button>
                        )
                      ) : (
                        <button onClick={() => setBanTarget(u)} className="text-xs px-2 py-1 rounded bg-red-50 text-red-600 border border-red-200 hover:bg-red-100">
                          Ban
                        </button>
                      )
                    )}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </AdminTable>

      <BanModal
        isOpen={!!banTarget}
        username={banTarget?.username}
        onClose={() => setBanTarget(null)}
        onConfirm={handleBan}
        isLoading={banUser.isPending}
      />
    </div>
  );
}
