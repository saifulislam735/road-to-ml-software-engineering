import { catchAsync } from '../utils/catchAsync.js';
import { userService } from '../services/user.service.js';

export const userController = {
  getPublicProfile: catchAsync(async (req, res) => {
    const profile = await userService.getPublicProfile(req.params.username);
    res.json(profile);
  }),

  updateMe: catchAsync(async (req, res) => {
    const user = await userService.updateMe(req.user.id, req.body);
    res.json({ user });
  }),
};
