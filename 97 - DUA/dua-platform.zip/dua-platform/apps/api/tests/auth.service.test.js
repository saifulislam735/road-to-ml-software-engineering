import { jest } from '@jest/globals';

process.env.DATABASE_URL = 'postgresql://test';
process.env.JWT_SECRET = 'test-secret';

jest.unstable_mockModule('../src/repositories/user.repo.js', () => ({
  userRepo: {
    findByEmail: jest.fn(),
    findByUsername: jest.fn(),
    findById: jest.fn(),
    create: jest.fn(),
    update: jest.fn(),
  },
}));

const { userRepo } = await import('../src/repositories/user.repo.js');
const { authService } = await import('../src/services/auth.service.js');
const bcrypt = (await import('bcryptjs')).default;

describe('authService.register', () => {
  beforeEach(() => jest.clearAllMocks());

  it('creates a user and returns token + public user', async () => {
    userRepo.findByEmail.mockResolvedValue(null);
    userRepo.findByUsername.mockResolvedValue(null);
    userRepo.create.mockImplementation(async (data) => ({
      id: 'u1', role: 'USER', name: null, bio: null, avatarUrl: null, isPaused: false, ...data,
    }));

    const result = await authService.register({
      username: 'rafi', email: 'rafi@example.com', password: 'password123',
    });

    expect(result.token).toBeTruthy();
    expect(result.user.username).toBe('rafi');
    expect(result.user.password).toBeUndefined();
    expect(userRepo.create).toHaveBeenCalled();
    // password must be hashed
    const stored = userRepo.create.mock.calls[0][0].password;
    expect(stored).not.toBe('password123');
  });

  it('throws 409 when email is taken', async () => {
    userRepo.findByEmail.mockResolvedValue({ id: 'u1' });
    userRepo.findByUsername.mockResolvedValue(null);
    await expect(
      authService.register({ username: 'x', email: 'taken@x.com', password: 'password123' })
    ).rejects.toMatchObject({ statusCode: 409 });
  });
});

describe('authService.login', () => {
  beforeEach(() => jest.clearAllMocks());

  it('returns token for valid credentials', async () => {
    const hash = await bcrypt.hash('password123', 4);
    userRepo.findByEmail.mockResolvedValue({
      id: 'u1', username: 'rafi', email: 'rafi@example.com', password: hash,
      isBanned: false, role: 'USER', name: null, bio: null, avatarUrl: null, isPaused: false,
    });
    const result = await authService.login({ email: 'rafi@example.com', password: 'password123' });
    expect(result.token).toBeTruthy();
  });

  it('rejects wrong password with 401', async () => {
    const hash = await bcrypt.hash('password123', 4);
    userRepo.findByEmail.mockResolvedValue({ id: 'u1', password: hash, isBanned: false });
    await expect(
      authService.login({ email: 'rafi@example.com', password: 'wrong' })
    ).rejects.toMatchObject({ statusCode: 401 });
  });

  it('rejects banned user with 403', async () => {
    const hash = await bcrypt.hash('password123', 4);
    userRepo.findByEmail.mockResolvedValue({ id: 'u1', password: hash, isBanned: true });
    await expect(
      authService.login({ email: 'banned@x.com', password: 'password123' })
    ).rejects.toMatchObject({ statusCode: 403, message: 'Your account has been suspended.' });
  });
});
