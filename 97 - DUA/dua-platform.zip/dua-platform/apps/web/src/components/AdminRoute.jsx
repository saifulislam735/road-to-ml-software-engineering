import { Navigate, Outlet } from 'react-router-dom';
import { useAuthStore } from '../store/authStore';
import Spinner from './ui/Spinner';

export default function AdminRoute() {
  const { user, hydrated } = useAuthStore();
  if (!hydrated) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Spinner size="lg" className="text-brand-600" />
      </div>
    );
  }
  if (!user) return <Navigate to="/login" replace />;
  if (user.role !== 'ADMIN') return <Navigate to="/inbox" replace />;
  return <Outlet />;
}
