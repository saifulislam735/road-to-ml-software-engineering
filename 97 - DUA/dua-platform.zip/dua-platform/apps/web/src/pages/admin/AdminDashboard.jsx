import { Link } from 'react-router-dom';
import { Users, MessageSquare, Flag, Ban } from 'lucide-react';
import {
  LineChart, Line, BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid,
} from 'recharts';
import StatCard from '../../components/admin/StatCard';
import Spinner from '../../components/ui/Spinner';
import { useAdminStats, useAdminChart } from '../../hooks/useAdmin';
import { relativeTime, truncate } from '../../utils/helpers';

export default function AdminDashboard() {
  const { data: stats, isLoading } = useAdminStats();
  const { data: duasChart } = useAdminChart('duas_daily');
  const { data: usersChart } = useAdminChart('users_daily');

  if (isLoading) {
    return <div className="flex justify-center py-20"><Spinner size="lg" className="text-brand-600" /></div>;
  }

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard title="Total Users" value={stats?.users?.total || 0} color="blue" icon={Users} />
        <StatCard title="Duas Today" value={stats?.duas?.today || 0} color="green" icon={MessageSquare} />
        <StatCard title="Pending Reports" value={stats?.reports?.pending || 0} color="orange" icon={Flag} />
        <StatCard title="Banned Users" value={stats?.users?.banned || 0} color="red" icon={Ban} />
      </div>

      <div className="grid lg:grid-cols-2 gap-4">
        <div className="bg-white rounded-xl border border-gray-100 shadow-sm p-4">
          <h2 className="text-sm font-semibold text-gray-700 mb-3">Duas per day — last 7 days</h2>
          <div className="h-52">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={duasChart || []}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                <XAxis dataKey="date" tick={{ fontSize: 11 }} tickFormatter={(d) => d.slice(5)} />
                <YAxis tick={{ fontSize: 11 }} allowDecimals={false} />
                <Tooltip />
                <Line type="monotone" dataKey="count" stroke="#16a34a" strokeWidth={2} dot={false} isAnimationActive={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
        <div className="bg-white rounded-xl border border-gray-100 shadow-sm p-4">
          <h2 className="text-sm font-semibold text-gray-700 mb-3">New users per day — last 7 days</h2>
          <div className="h-52">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={usersChart || []}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                <XAxis dataKey="date" tick={{ fontSize: 11 }} tickFormatter={(d) => d.slice(5)} />
                <YAxis tick={{ fontSize: 11 }} allowDecimals={false} />
                <Tooltip />
                <Bar dataKey="count" fill="#3b82f6" radius={[4, 4, 0, 0]} isAnimationActive={false} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      <div className="grid lg:grid-cols-2 gap-4">
        <div className="bg-white rounded-xl border border-gray-100 shadow-sm p-4">
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-sm font-semibold text-gray-700">Pending reports</h2>
            <Link to="/admin/reports" className="text-xs text-brand-600 hover:underline">View pending reports →</Link>
          </div>
          {stats?.recent?.reports?.length ? (
            <ul className="space-y-2">
              {stats.recent.reports.map((r) => (
                <li key={r.id} className="text-sm flex items-start justify-between gap-2 border-b border-gray-50 pb-2">
                  <span className="text-gray-600">"{truncate(r.dua?.message, 50)}"</span>
                  <span className="text-xs text-gray-400 shrink-0">{relativeTime(r.createdAt)}</span>
                </li>
              ))}
            </ul>
          ) : (
            <p className="text-sm text-gray-400">All clear — no pending reports.</p>
          )}
        </div>
        <div className="bg-white rounded-xl border border-gray-100 shadow-sm p-4">
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-sm font-semibold text-gray-700">New users</h2>
            <Link to="/admin/users" className="text-xs text-brand-600 hover:underline">View all users →</Link>
          </div>
          {stats?.recent?.users?.length ? (
            <ul className="space-y-2">
              {stats.recent.users.map((u) => (
                <li key={u.id} className="text-sm flex items-center justify-between border-b border-gray-50 pb-2">
                  <Link to={`/admin/users/${u.id}`} className="text-gray-700 hover:text-brand-600">@{u.username}</Link>
                  <span className="text-xs text-gray-400">{relativeTime(u.createdAt)}</span>
                </li>
              ))}
            </ul>
          ) : (
            <p className="text-sm text-gray-400">No users yet.</p>
          )}
        </div>
      </div>
    </div>
  );
}
