import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Eye, EyeOff, Trash2 } from 'lucide-react';
import toast from 'react-hot-toast';
import { useAdminDuas, useHideDua, useAdminDeleteDua } from '../../hooks/useAdmin';
import AdminTable from '../../components/admin/AdminTable';
import Badge from '../../components/ui/Badge';
import { relativeTime, truncate, apiError } from '../../utils/helpers';

const TABS = [
  { key: 'all', label: 'All' },
  { key: 'reported', label: 'Reported' },
  { key: 'hidden', label: 'Hidden' },
];

export default function AdminDuas() {
  const [tab, setTab] = useState('all');
  const [page, setPage] = useState(1);
  const [expandedId, setExpandedId] = useState(null);
  const [confirmDeleteId, setConfirmDeleteId] = useState(null);

  const params = {
    page,
    limit: 20,
    ...(tab === 'reported' ? { reported: 'true' } : {}),
    ...(tab === 'hidden' ? { hidden: 'true' } : {}),
  };

  const { data, isLoading, error, refetch } = useAdminDuas(params);
  const hideDua = useHideDua();
  const deleteDua = useAdminDeleteDua();

  const duas = data?.duas ?? [];
  const pagination = data?.pagination;

  const switchTab = (key) => {
    setTab(key);
    setPage(1);
    setExpandedId(null);
    setConfirmDeleteId(null);
  };

  const toggleHide = (dua) => {
    hideDua.mutate(
      { id: dua.id, hidden: !dua.isHidden },
      { onError: (e) => toast.error(apiError(e)) }
    );
  };

  const handleDelete = (id) => {
    deleteDua.mutate(id, {
      onSuccess: () => { toast.success('Dua deleted'); setConfirmDeleteId(null); },
      onError: (e) => toast.error(apiError(e)),
    });
  };

  return (
    <div className="space-y-4">
      <h1 className="text-xl font-semibold text-gray-900">Duas</h1>

      <div className="flex gap-1 bg-gray-100 rounded-lg p-1 w-fit">
        {TABS.map((t) => (
          <button
            key={t.key}
            onClick={() => switchTab(t.key)}
            className={`px-4 py-1.5 rounded-md text-sm font-medium transition-colors ${
              tab === t.key ? 'bg-white shadow-sm text-gray-900' : 'text-gray-500 hover:text-gray-700'
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      <AdminTable
        isLoading={isLoading}
        error={error}
        isEmpty={duas.length === 0}
        emptyMessage="No duas found."
        pagination={pagination}
        onPageChange={setPage}
        onRetry={refetch}
      >
        <table className="w-full text-sm">
          <thead>
            <tr className="text-left text-xs uppercase text-gray-400 border-b border-gray-100">
              <th className="px-4 py-2 font-medium">Message</th>
              <th className="px-4 py-2 font-medium">Sent to</th>
              <th className="px-4 py-2 font-medium">Date</th>
              <th className="px-4 py-2 font-medium">Reports</th>
              <th className="px-4 py-2 font-medium">Status</th>
              <th className="px-4 py-2 font-medium text-right">Actions</th>
            </tr>
          </thead>
          <tbody>
            {duas.map((dua, i) => (
              <tr key={dua.id} className={i % 2 ? 'bg-gray-50/60' : ''}>
                <td
                  className="px-4 py-3 text-gray-700 cursor-pointer max-w-xs"
                  onClick={() => setExpandedId(expandedId === dua.id ? null : dua.id)}
                >
                  {expandedId === dua.id ? dua.message : truncate(dua.message, 60)}
                </td>
                <td className="px-4 py-3 whitespace-nowrap">
                  <Link to={`/admin/users/${dua.owner.id}`} className="text-brand-700 hover:underline">
                    @{dua.owner.username}
                  </Link>
                </td>
                <td className="px-4 py-3 text-gray-400 whitespace-nowrap">{relativeTime(dua.createdAt)}</td>
                <td className="px-4 py-3">
                  {dua.reportCount > 0
                    ? <Badge color="red">{dua.reportCount}</Badge>
                    : <span className="text-gray-300">—</span>}
                </td>
                <td className="px-4 py-3">
                  {dua.isHidden ? <Badge color="orange">Hidden</Badge> : <Badge color="green">Visible</Badge>}
                </td>
                <td className="px-4 py-3 text-right whitespace-nowrap">
                  <button
                    className="inline-flex items-center gap-1 text-xs text-gray-500 hover:text-gray-800 mr-3"
                    onClick={() => toggleHide(dua)}
                  >
                    {dua.isHidden ? <Eye size={14} /> : <EyeOff size={14} />}
                    {dua.isHidden ? 'Show' : 'Hide'}
                  </button>
                  {confirmDeleteId === dua.id ? (
                    <span className="text-xs">
                      <button className="text-red-600 font-medium mr-2" onClick={() => handleDelete(dua.id)}>
                        Confirm
                      </button>
                      <button className="text-gray-400" onClick={() => setConfirmDeleteId(null)}>Cancel</button>
                    </span>
                  ) : (
                    <button
                      className="inline-flex items-center gap-1 text-xs text-red-500 hover:text-red-700"
                      onClick={() => setConfirmDeleteId(dua.id)}
                    >
                      <Trash2 size={14} /> Delete
                    </button>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </AdminTable>
    </div>
  );
}
