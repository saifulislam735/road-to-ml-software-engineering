import { useState } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { ArrowLeft, Eye, EyeOff, Trash2 } from 'lucide-react';
import toast from 'react-hot-toast';
import {
  useAdminUser, useBanUser, useUnbanUser, useDeleteUser,
  useHideDua, useAdminDeleteDua,
} from '../../hooks/useAdmin';
import Avatar from '../../components/ui/Avatar';
import Badge from '../../components/ui/Badge';
import Button from '../../components/ui/Button';
import Spinner from '../../components/ui/Spinner';
import BanModal from '../../components/admin/BanModal';
import ConfirmModal from '../../components/admin/ConfirmModal';
import { relativeTime, formatDate, truncate, apiError } from '../../utils/helpers';

export default function AdminUserDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { data: user, isLoading, error } = useAdminUser(id);

  const banUser = useBanUser();
  const unbanUser = useUnbanUser();
  const deleteUser = useDeleteUser();
  const hideDua = useHideDua();
  const deleteDua = useAdminDeleteDua();

  const [banOpen, setBanOpen] = useState(false);
  const [deleteOpen, setDeleteOpen] = useState(false);
  const [expandedId, setExpandedId] = useState(null);
  const [confirmDeleteDuaId, setConfirmDeleteDuaId] = useState(null);

  if (isLoading) {
    return <div className="flex justify-center py-20"><Spinner /></div>;
  }
  if (error || !user) {
    return (
      <div className="bg-red-50 border border-red-100 rounded-xl p-6 text-center text-sm text-red-700">
        User not found.
        <div className="mt-3">
          <Link to="/admin/users" className="text-brand-700 underline">Back to users</Link>
        </div>
      </div>
    );
  }

  const handleBan = (reason) => {
    banUser.mutate(
      { id: user.id, reason },
      {
        onSuccess: () => { toast.success(`@${user.username} banned`); setBanOpen(false); },
        onError: (e) => toast.error(apiError(e)),
      }
    );
  };

  const handleUnban = () => {
    unbanUser.mutate(user.id, {
      onSuccess: () => toast.success(`@${user.username} unbanned`),
      onError: (e) => toast.error(apiError(e)),
    });
  };

  const handleDelete = () => {
    deleteUser.mutate(user.id, {
      onSuccess: () => { toast.success('User deleted'); navigate('/admin/users'); },
      onError: (e) => toast.error(apiError(e)),
    });
  };

  const toggleHide = (dua) => {
    hideDua.mutate(
      { id: dua.id, hidden: !dua.isHidden },
      { onError: (e) => toast.error(apiError(e)) }
    );
  };

  const handleDeleteDua = (duaId) => {
    deleteDua.mutate(duaId, {
      onSuccess: () => { toast.success('Dua deleted'); setConfirmDeleteDuaId(null); },
      onError: (e) => toast.error(apiError(e)),
    });
  };

  return (
    <div className="space-y-6">
      <Link to="/admin/users" className="inline-flex items-center gap-1 text-sm text-gray-500 hover:text-gray-700">
        <ArrowLeft size={16} /> Back to users
      </Link>

      {/* Profile section */}
      <div className="bg-white rounded-xl border border-gray-100 shadow-sm p-6">
        <div className="flex items-start gap-4">
          <Avatar name={user.name || user.username} src={user.avatarUrl} size="lg" />
          <div className="min-w-0">
            <div className="flex flex-wrap items-center gap-2">
              <h1 className="text-lg font-semibold text-gray-900">{user.name || user.username}</h1>
              <Badge color={user.role === 'ADMIN' ? 'blue' : 'gray'}>{user.role}</Badge>
              {user.isBanned
                ? <Badge color="red">Banned</Badge>
                : <Badge color="green">Active</Badge>}
              {user.isPaused && <Badge color="orange">Paused</Badge>}
            </div>
            <p className="text-sm text-gray-500 mt-0.5">@{user.username} · {user.email}</p>
            <p className="text-xs text-gray-400 mt-1">Joined {formatDate(user.createdAt)}</p>
            {user.isBanned && user.banReason && (
              <p className="text-xs text-red-600 mt-2">Ban reason: {user.banReason}</p>
            )}
            {user.bio && <p className="text-sm text-gray-600 mt-2">{user.bio}</p>}
          </div>
        </div>
        <div className="grid grid-cols-2 gap-4 mt-6">
          <div className="bg-gray-50 rounded-lg p-4 text-center">
            <p className="text-2xl font-semibold text-gray-900">{user.duasReceived}</p>
            <p className="text-xs text-gray-500 mt-1">Total duas received</p>
          </div>
          <div className="bg-gray-50 rounded-lg p-4 text-center">
            <p className="text-2xl font-semibold text-gray-900">{user.reportCount}</p>
            <p className="text-xs text-gray-500 mt-1">Reports against their duas</p>
          </div>
        </div>
      </div>

      {/* Duas section */}
      <div className="bg-white rounded-xl border border-gray-100 shadow-sm overflow-hidden">
        <h2 className="px-4 pt-4 pb-2 text-sm font-semibold text-gray-900">Duas received (last 20)</h2>
        {user.duas.length === 0 ? (
          <p className="px-4 pb-6 text-sm text-gray-400">No duas yet.</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left text-xs uppercase text-gray-400 border-b border-gray-100">
                  <th className="px-4 py-2 font-medium">Message</th>
                  <th className="px-4 py-2 font-medium">Date</th>
                  <th className="px-4 py-2 font-medium">Reports</th>
                  <th className="px-4 py-2 font-medium">Status</th>
                  <th className="px-4 py-2 font-medium text-right">Actions</th>
                </tr>
              </thead>
              <tbody>
                {user.duas.map((dua, i) => (
                  <tr key={dua.id} className={i % 2 ? 'bg-gray-50/60' : ''}>
                    <td
                      className="px-4 py-3 text-gray-700 cursor-pointer max-w-xs"
                      onClick={() => setExpandedId(expandedId === dua.id ? null : dua.id)}
                    >
                      {expandedId === dua.id ? dua.message : truncate(dua.message, 60)}
                    </td>
                    <td className="px-4 py-3 text-gray-400 whitespace-nowrap">{relativeTime(dua.createdAt)}</td>
                    <td className="px-4 py-3">
                      {dua._count?.reports > 0
                        ? <Badge color="red">{dua._count.reports}</Badge>
                        : <span className="text-gray-300">—</span>}
                    </td>
                    <td className="px-4 py-3">
                      {dua.isHidden ? <Badge color="orange">Hidden</Badge> : <Badge color="green">Visible</Badge>}
                    </td>
                    <td className="px-4 py-3 text-right whitespace-nowrap">
                      <button
                        className="inline-flex items-center gap-1 text-xs text-gray-500 hover:text-gray-800 mr-3"
                        onClick={() => toggleHide(dua)}
                      >
                        {dua.isHidden ? <Eye size={14} /> : <EyeOff size={14} />}
                        {dua.isHidden ? 'Show' : 'Hide'}
                      </button>
                      {confirmDeleteDuaId === dua.id ? (
                        <span className="text-xs">
                          <button className="text-red-600 font-medium mr-2" onClick={() => handleDeleteDua(dua.id)}>
                            Confirm
                          </button>
                          <button className="text-gray-400" onClick={() => setConfirmDeleteDuaId(null)}>Cancel</button>
                        </span>
                      ) : (
                        <button
                          className="inline-flex items-center gap-1 text-xs text-red-500 hover:text-red-700"
                          onClick={() => setConfirmDeleteDuaId(dua.id)}
                        >
                          <Trash2 size={14} /> Delete
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Danger zone */}
      <div className="bg-white rounded-xl border-2 border-red-200 shadow-sm p-6">
        <h2 className="text-sm font-semibold text-red-700">Danger zone</h2>
        <div className="mt-4 space-y-4">
          <div className="flex items-center justify-between gap-4">
            <div>
              <p className="text-sm font-medium text-gray-900">{user.isBanned ? 'Unban user' : 'Ban user'}</p>
              <p className="text-xs text-gray-500">
                {user.isBanned
                  ? 'Restore login access for this user.'
                  : 'Blocks login and hides all of their duas.'}
              </p>
            </div>
            {user.isBanned ? (
              <Button variant="secondary" onClick={handleUnban} isLoading={unbanUser.isPending}>Unban</Button>
            ) : (
              <Button
                variant="danger"
                onClick={() => setBanOpen(true)}
                disabled={user.role === 'ADMIN'}
              >
                Ban
              </Button>
            )}
          </div>
          <div className="border-t border-gray-100 pt-4 flex items-center justify-between gap-4">
            <div>
              <p className="text-sm font-medium text-gray-900">Delete account</p>
              <p className="text-xs text-gray-500">Permanently removes the user and all their duas.</p>
            </div>
            <Button
              variant="danger"
              onClick={() => setDeleteOpen(true)}
              disabled={user.role === 'ADMIN'}
            >
              Delete permanently
            </Button>
          </div>
        </div>
      </div>

      <BanModal
        isOpen={banOpen}
        onClose={() => setBanOpen(false)}
        onConfirm={handleBan}
        username={user.username}
        isLoading={banUser.isPending}
      />
      <ConfirmModal
        isOpen={deleteOpen}
        onClose={() => setDeleteOpen(false)}
        onConfirm={handleDelete}
        title={`Delete @${user.username}?`}
        message="This will delete the user and all their duas. This cannot be undone."
        confirmLabel="Delete permanently"
        isDanger
        isLoading={deleteUser.isPending}
      />
    </div>
  );
}
