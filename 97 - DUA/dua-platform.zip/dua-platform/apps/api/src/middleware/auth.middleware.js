import jwt from 'jsonwebtoken';
import { env } from '../config/env.js';

export function authMiddleware(req, res, next) {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;

  if (!token) {
    return res.status(401).json({ error: true, message: 'Not authenticated', code: 'NO_TOKEN' });
  }

  try {
    const decoded = jwt.verify(token, env.jwtSecret);
    req.user = { id: decoded.id, username: decoded.username, email: decoded.email, role: decoded.role };
    return next();
  } catch {
    return res.status(401).json({ error: true, message: 'Invalid or expired token', code: 'INVALID_TOKEN' });
  }
}
