import { useState, useEffect } from 'react';
import toast from 'react-hot-toast';
import { Link } from 'react-router-dom';
import Navbar from '../components/Navbar';
import DuaCard from '../components/DuaCard';
import Spinner from '../components/ui/Spinner';
import Button from '../components/ui/Button';
import { useInbox, useDeleteDua, useMarkRead } from '../hooks/useDuas';
import { apiError } from '../utils/helpers';

export default function Inbox() {
  const [page, setPage] = useState(1);
  const { data, isLoading, error } = useInbox(page);
  const deleteDua = useDeleteDua();
  const markRead = useMarkRead();

  // Mark visible unread duas as read on load
  useEffect(() => {
    if (data?.duas) {
      data.duas.filter((d) => !d.isRead).forEach((d) => markRead.mutate(d.id));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [data?.duas?.map((d) => d.id).join(',')]);

  const handleDelete = (id) => {
    deleteDua.mutate(id, {
      onSuccess: () => toast.success('Dua deleted'),
      onError: (err) => toast.error(apiError(err)),
    });
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      <main className="max-w-lg mx-auto px-4 py-6">
        <h1 className="text-xl font-semibold text-gray-900 mb-4">Your duas</h1>

        {isLoading && (
          <div className="flex justify-center py-12">
            <Spinner size="lg" className="text-brand-600" />
          </div>
        )}

        {error && (
          <div className="bg-red-50 border border-red-100 rounded-xl p-4 text-sm text-red-700">
            Couldn't load your inbox. Please refresh.
          </div>
        )}

        {data && data.duas.length === 0 && (
          <div className="text-center py-16">
            <div className="text-5xl mb-3">🤲</div>
            <h2 className="font-semibold text-gray-900">No duas yet</h2>
            <p className="text-sm text-gray-500 mt-1 max-w-xs mx-auto">
              Share your link with friends and family — your first dua is on its way, insha'Allah.
            </p>
            <Link to="/share">
              <Button className="mt-4">Share your link</Button>
            </Link>
          </div>
        )}

        <div className="space-y-3">
          {data?.duas.map((dua) => (
            <DuaCard key={dua.id} dua={dua} onDelete={handleDelete} isDeleting={deleteDua.isPending} />
          ))}
        </div>

        {data && data.pagination.totalPages > 1 && (
          <div className="flex justify-center mt-6">
            {page < data.pagination.totalPages ? (
              <Button variant="secondary" onClick={() => setPage((p) => p + 1)}>
                Load more
              </Button>
            ) : (
              <p className="text-xs text-gray-400">You've reached the end</p>
            )}
          </div>
        )}
      </main>
    </div>
  );
}
