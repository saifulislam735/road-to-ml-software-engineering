import { authMiddleware } from './auth.middleware.js';

export function adminAuthMiddleware(req, res, next) {
  authMiddleware(req, res, (err) => {
    if (err) return next(err);
    if (!req.user) return; // authMiddleware already responded with 401
    if (req.user.role !== 'ADMIN') {
      return res.status(403).json({ error: true, message: 'Admin access required', code: 'FORBIDDEN' });
    }
    return next();
  });
}
