# Dua Platform

Anonymous dua-sending web app (NGL-style). Users get a public link (`/u/username`) where anyone can send them a dua anonymously. Includes a full admin panel for moderation.

## Stack

| Layer    | Tech |
|----------|------|
| Backend  | Node 20, Express, Prisma, PostgreSQL 16, Redis 7 (rate limiting), JWT, Zod |
| Frontend | React 18, Vite, Tailwind CSS, Zustand, TanStack Query v5, React Hook Form, Recharts |
| Infra    | Docker Compose, Nginx reverse proxy, Let's Encrypt, Uptime Kuma, GitHub Actions → GHCR |

## Repo structure

```
dua-platform/
├── apps/
│   ├── api/          # Express API (route → controller → service → repository)
│   └── web/          # React app (public site + /admin panel)
├── infra/
│   ├── nginx/        # reverse proxy configs (prod)
│   └── docker/postgres/  # tuned postgresql.conf for a 4GB VPS
├── scripts/
│   └── backup-db.sh  # daily pg_dump backup with 7-day retention
├── docker-compose.yml       # dev: postgres + redis only
├── docker-compose.prod.yml  # prod: full stack behind nginx
└── .github/workflows/deploy.yml  # CI: build images → push GHCR → SSH deploy
```

## Quick start (local dev)

```bash
# 1. Install deps (npm workspaces)
npm install

# 2. Env files
cp apps/api/.env.example apps/api/.env
cp apps/web/.env.example apps/web/.env

# 3. Start postgres + redis
docker compose up -d

# 4. Migrate + seed (creates test + admin users)
cd apps/api
npx prisma migrate dev --name init
npx prisma db seed
cd ../..

# 5. Run both apps (two terminals)
npm run dev:api   # http://localhost:5000
npm run dev:web   # http://localhost:5173
```

Seeded logins:
- `test@example.com` / `password123`
- Admin: from `ADMIN_EMAIL` / `ADMIN_PASSWORD` in `apps/api/.env`

## Tests

```bash
npm run test:api
```

## Deployment

See the deploy guide in the project chat / docs. Summary: push to GitHub → Actions builds images to GHCR → SSH deploy to the VPS running `docker-compose.prod.yml`, with nginx + Let's Encrypt in front and Uptime Kuma on `:3001`.
