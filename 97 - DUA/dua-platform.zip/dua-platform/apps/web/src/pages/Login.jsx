import { Link, useNavigate } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import toast from 'react-hot-toast';
import Input from '../components/ui/Input';
import Button from '../components/ui/Button';
import { useLogin } from '../hooks/useAuth';
import { apiError } from '../utils/helpers';

const schema = z.object({
  email: z.string().email('Enter a valid email'),
  password: z.string().min(1, 'Password is required'),
});

export default function Login() {
  const navigate = useNavigate();
  const login = useLogin();
  const { register, handleSubmit, formState: { errors } } = useForm({ resolver: zodResolver(schema) });

  const onSubmit = (data) => {
    login.mutate(data, {
      onSuccess: () => navigate('/inbox'),
      onError: (err) => toast.error(apiError(err, 'Login failed')),
    });
  };

  return (
    <div className="min-h-screen flex items-center justify-center px-4 bg-gray-50">
      <div className="w-full max-w-sm bg-white rounded-xl shadow-sm border border-gray-100 p-6">
        <Link to="/" className="block text-center text-3xl mb-2">🤲</Link>
        <h1 className="text-xl font-semibold text-center text-gray-900">Welcome back</h1>
        <p className="text-sm text-gray-500 text-center mb-6">Log in to read your duas</p>
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
          <Input label="Email" type="email" placeholder="you@example.com" error={errors.email?.message} {...register('email')} />
          <Input label="Password" type="password" placeholder="••••••••" error={errors.password?.message} {...register('password')} />
          <Button type="submit" isLoading={login.isPending} className="w-full">Log in</Button>
        </form>
        <p className="text-sm text-gray-500 text-center mt-4">
          New here?{' '}
          <Link to="/register" className="text-brand-600 font-medium hover:underline">Create an account</Link>
        </p>
      </div>
    </div>
  );
}
