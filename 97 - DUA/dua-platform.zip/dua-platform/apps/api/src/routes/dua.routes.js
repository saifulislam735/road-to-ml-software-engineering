import { Router } from 'express';
import { z } from 'zod';
import { duaController } from '../controllers/dua.controller.js';
import { authMiddleware } from '../middleware/auth.middleware.js';
import { validate } from '../middleware/validate.middleware.js';
import { duaSendLimiter, reportLimiter } from '../middleware/rateLimit.middleware.js';

const sendDuaSchema = z.object({
  message: z.string().min(10, 'Message must be at least 10 characters').max(500),
});

const reportSchema = z.object({
  reason: z.string().min(5).max(300),
});

const router = Router();

router.post('/send/:username', duaSendLimiter, validate(sendDuaSchema), duaController.send);
router.get('/inbox', authMiddleware, duaController.inbox);
router.patch('/:id/read', authMiddleware, duaController.markRead);
router.delete('/:id', authMiddleware, duaController.delete);
router.post('/:id/report', reportLimiter, validate(reportSchema), duaController.report);

export default router;
