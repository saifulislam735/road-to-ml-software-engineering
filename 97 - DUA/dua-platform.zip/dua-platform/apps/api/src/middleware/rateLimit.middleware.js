import rateLimit from 'express-rate-limit';
import { RedisStore } from 'rate-limit-redis';
import { createClient } from 'redis';
import { env } from '../config/env.js';

const redisClient = createClient({ url: env.redisUrl });
redisClient.on('error', (err) => console.error('Redis error:', err.message));
await redisClient.connect();

const limitResponse = {
  error: true,
  message: 'Too many requests. Please try again later.',
  code: 'RATE_LIMITED',
};

function makeLimiter({ windowMs, max, prefix }) {
  return rateLimit({
    windowMs,
    max,
    standardHeaders: true,
    legacyHeaders: false,
    message: limitResponse,
    store: new RedisStore({
      sendCommand: (...args) => redisClient.sendCommand(args),
      prefix,
    }),
  });
}

// Anonymous dua send: 5 per 15 minutes per IP
export const duaSendLimiter = makeLimiter({ windowMs: 15 * 60 * 1000, max: 5, prefix: 'rl:send:' });

// Auth endpoints: 10 per 15 minutes per IP
export const authLimiter = makeLimiter({ windowMs: 15 * 60 * 1000, max: 10, prefix: 'rl:auth:' });

// Anonymous report: 5 per 15 minutes per IP
export const reportLimiter = makeLimiter({ windowMs: 15 * 60 * 1000, max: 5, prefix: 'rl:report:' });
